LEAVE_TYPE_LIST = [
    # ('Select Leave Type','Select Leave Type'),
    ('Single Day', 'Single Day'),
    ('Annual', 'Annual'),
]

# ('Single Day', 'Single Day'),
# ('Annual', 'Annual'),
# Half Day,Single Day,Annual,EO Paid,Unpaid,EO Half Day,Unpaid Half Day

# List of LEAVE STATUS
STATUS_CHOICE = [
    ('Choose...', 'Choose...'),
    ('APPROVED', 'APPROVED'),
    ('DECLINED', 'DECLINED'),
]

APPROVE_CATEGORY = [
    ('Choose...', 'Choose...'),
    ('UNPAID', 'UNPAID'),
    ('PAID', 'PAID'),
    ('EO PAID', 'EO PAID')
]

FY_CHOICE = [
    ('FY2018-19', 'FY2018-19'),
    ('FY2019-20', 'FY2019-20')
]

HOLIDAY_TYPE_CHOICE = [
    ('FIXED', 'FIXED'),
    ('OPTIONAL', 'OPTIONAL')
]

LEAVE_FOR_CHOICE = [
    ('Full Day', 'Full Day'),
    ('First Half', 'First Half'),
    ('Second Half', 'Second Half')
]
