# List of Company
# COMPANY_LIST = (
#     ('InnerHeads', ('InnerHeads')),
#     ('Mobiefit', ('Mobiefit')),
#     ('HandyTraining', ('HandyTraining')),
#     ('TempoGo', ('TempoGo')),
#     ('Seynse', ('Seynse')),
#     ('Mondeart', ('Mondeart')),
#     ('Synapse', ('Synapse')),
#     ('Visual Juju', ('Visual Juju')),
#     ('ScreenRoot', ('ScreenRoot')),
#     ('Junoon Ventures', ('Junoon Ventures')),
#     ('Pvt Unlimited', ('Pvt Unlimited')),
#     ('Prototyze', ('Prototyze')),
# )

# List of Group Company
GROUP_COMPANY_LIST = (
    ('Prototyze', 'Prototyze'),
    ('Pvt Unlimited', 'Pvt Unlimited'),
    ('InnerHeads', 'InnerHeads'),
)

# List of Work Location
WORK_LOCATION = (
    ('Goa', 'Goa'),
    ('Gurugram', 'Gurugram'),
    ('New Delhi', 'New Delhi'),
    ('Mumbai', 'Mumbai'),
    ('Pune', 'Pune'),
)

# List of Employee Setup
EMPLOYMENT_SETUP = (
    ('Employment', 'Employment'),
    ('Professional', 'Professional'),
    ('Intern', 'Intern'),
)

# List of Gender
GENDER_LIST = (
    ('Male', 'Male'),
    ('Female', 'Female'),
)

# List of Marital Status
MARITAL_STATUS_LIST = (
    ('Single', 'Single'),
    ('Married', 'Married'),
)

# List of User Type
USER_TYPE_LIST = (
    ('User', 'User'),
    ('Manager', 'Manager'),
    ('HR', 'HR'),
    ('Admin', 'Admin'),
)

# List of Weekend Day
WEEKEND_DAY_LIST = (
    (1, 1),
    (2, 2),
)

# List of Employee Status
EMPLOYEE_STATUS_LIST = (
    ('Active', 'Active'),
    ('Inactive', 'Inactive'),
)

# List of LEAVE CATEGORY
# LEAVE_CATEGORY_LIST = [
#     ('M1', 'M1'),
#     ('M2', 'M2'),
#     ('M3', 'M3'),
#     ('Intern', 'Intern'),
# ]
