from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.shortcuts import render
from service.models import service,product
from django.shortcuts import render, get_object_or_404
from service.models import Appointment
from django.contrib import messages
from datetime import datetime, timedelta
from django.utils.dateparse import parse_time
from django.utils import timezone
from django.db.models import F, ExpressionWrapper, DurationField, TimeField
from datetime import time

# views.py

def home(request):
    return render(request,"home.html")

def index(request):   
    return render(request,"home.html")

def bookservice(request,id):
    item = get_object_or_404(service, pk=id)    
    return render(request,"bookservice.html",{'service': item})

def Product(request):
    pr = product.objects.all()
    data={
        'productData':pr
    }
    return render(request,"Product.html",data)

def services(request):
    serviceData=service.objects.all()
    
    data={
        'serviceData':serviceData
    }
    return render(request,"services.html",data)

def to_integer(dt_time):
    return 10000*dt_time.year + 100*dt_time.month + dt_time.day


def calculate_total_time(time_values):
    total_duration = timedelta()  # Initialize total duration as zero timedelta
    
    for time_str in time_values:
        # Convert time string (e.g., '02:30') to a time object
        time_obj = datetime.strptime(time_str, '%H:%M').time()
        
        # Convert time object to timedelta (hours and minutes only)
        time_delta = timedelta(hours=time_obj.hour, minutes=time_obj.minute)
        
        # Add each time duration to the total duration
        total_duration += time_delta
    
    # Get total hours and minutes
    total_hours = total_duration.seconds // 3600
    total_minutes = (total_duration.seconds % 3600) // 60

    return total_hours, total_minutes


def save(request):
    if request.method == "POST":
        email = request.POST.get('email')
        full_name = request.POST.get('full_name')
        phone_number = request.POST.get('phone_number')
        appointment_date = request.POST.get('appointment_date')
        preferred_time_str = request.POST.get('preferred_time')
        serviceid = request.POST.get('serviceid')
        
        # Parse preferred_time into a Python time object
        # preferred_time = parse_time(preferred_time)
         # Convert the preferred_time to a datetime object
        preferred_time = datetime.strptime(preferred_time_str, '%H:%M')
        # Get the selected service IDs
        service_ids = request.POST.getlist('service_ids')
        error_message = None  # To store error messages
        if(len(service_ids) > 0):
            total_time = timedelta(hours=preferred_time.hour, minutes=preferred_time.minute)
            appointment_end_time = preferred_time.hour
            appointment_end_menits = 0
            newstart_time = str(preferred_time.hour) +":"+ str(preferred_time.minute)
            # Loop through each service to check for existing appointments with overlapping times
            for service_id in service_ids:
                services = service.objects.get(Service_title=service_id)  # Get the service to retrieve its duration
                # ts =  to_integer(services.service_time)
                # Calculate the end time of the service based on service_time duration
                end_time = timedelta(hours=services.service_time.hour, minutes=services.service_time.minute)
                total_time += end_time 
                # service_duration = services.service_time  
                # appointment_end_time = appointment_end_time + service_duration.hour
                # if(service_duration.minute < 60):
                #     appointment_end_menits += service_duration.minute 
                # else:
                #     appointment_end_time += 1

            hours, remainder = divmod(total_time.seconds, 3600)
            minutes = remainder // 60    
            newend_time = str(hours) + ":"+str(minutes)
            query = """
                SELECT 
                    a.id,
                    a.appointment_date,
                    a.preferred_time AS start_time,
                    ADDTIME(a.preferred_time, s.service_time) AS end_time,
                    s.service_time
                FROM 
                    service_appointment a
                LEFT JOIN 
                    service_service s 
                ON 
                    s.Service_title = a.service_name
                WHERE 
                    ADDTIME(a.preferred_time, s.service_time) > %s 
                AND  
                    a.preferred_time < %s 
                 and a.appointment_date = %s;
                """

                # Run the query using Django's raw() method and map it to the Appointment model
            results = Appointment.objects.raw(query,[newstart_time, newend_time,appointment_date])

            if len(results) > 0:
                error_message = "There is a conflicting appointment for this time."
            
            if error_message:
                return render(request, "services.html", {'error': error_message})  # Return error to template

            # Create a new appointment for each selected service if validation passes
            for service_id in service_ids:
                sr = Appointment(
                    email=email,
                    full_name=full_name,
                    phone_number=phone_number,
                    service_name=service_id,
                    appointment_date=appointment_date,
                    preferred_time=preferred_time
                )
                sr.save()
            success_message = 'Data is successfully saved.'
            return render(request, "services.html", {'success': success_message})      
        else:
           services = service.objects.get(id=serviceid)
        #    newhours = preferred_time.hour + services.service_time.hour
        #    mint = preferred_time.minute + services.service_time.minute
        #    if(mint >= 60):
        #        newhours += 1
        #        mint = 0
           start_time = timedelta(hours=preferred_time.hour, minutes=preferred_time.minute)
           end_time = timedelta(hours=services.service_time.hour, minutes=services.service_time.minute)

            # Sum the two time intervals
           total_time = start_time + end_time

            # Print the result in hours and minutes
           hours, remainder = divmod(total_time.seconds, 3600)
           minutes = remainder // 60
           appointment_end_timessnew = timezone.now().replace(hour=hours, minute=minutes, second=0, microsecond=0)
        #    conflicting_appointments = Appointment.objects.filter(
        #             appointment_date=appointment_date,
        #             service_name=services.Service_title,
        #             preferred_time__gte=preferred_time,  # Greater than or equal to the start time
        #             preferred_time__lte=appointment_end_timessnew  # Less than or equal to the end time
        #         )
           

        #    start_time_boundary = preferred_time  # Equivalent to '08:30:00'
        #    end_time_boundary = appointment_end_timessnew   # Equivalent to '10:30:00'
        #    start_time = preferred_time.hour +":"+ preferred_time.minute
        #    end_time = appointment_end_timessnew.hour +":"+appointment_end_timessnew.minute

           newend_time = str(hours) + ":"+str(minutes)
           newstart_time = str(preferred_time.hour) +":"+ str(preferred_time.minute)
        #    timedelta(hours=hours, minutes=minutes)
           query = """
                SELECT 
                    a.id,
                    a.appointment_date,
                    a.preferred_time AS start_time,
                    ADDTIME(a.preferred_time, s.service_time) AS end_time,
                    s.service_time
                FROM 
                    service_appointment a
                LEFT JOIN 
                    service_service s 
                ON 
                    s.Service_title = a.service_name
                WHERE 
                    ADDTIME(a.preferred_time, s.service_time) > %s 
                AND  
                    a.preferred_time < %s 
                 and a.appointment_date = %s;
                """

                # Run the query using Django's raw() method and map it to the Appointment model
           results = Appointment.objects.raw(query,[newstart_time, newend_time,appointment_date])
            
           if len(results) > 0:
                error_message = "There is a conflicting appointment for this time."
            
           if error_message:
                return render(request, "services.html", {'error': error_message})  # Return error to template
           
           srs = Appointment(
                email=email,
                full_name=full_name,
                phone_number=phone_number,
                service_name=services.Service_title,
                appointment_date=appointment_date,
                preferred_time=preferred_time
            )
           srs.save(); 
           success_message = 'Data is successfully saved.'
           return render(request, "services.html", {'success': success_message})

    return render(request, "services.html")

    # return render(request, "services.html")  # Render the form again for GET requests

# def Srvice(request):
#     SrviceData=Srvice.objects.all()
   
#     data={
#         'SrviceData':SrviceData
#     }
#     return render(request,"Product.html",data)
