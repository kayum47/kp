
from django.contrib import admin
from service.models import service
from service.models import Appointment
from service.models import product
# Register your models here.



class ServiceAdmin(admin.ModelAdmin):
    list_display=('Service_title','image')

admin.site.register(service,ServiceAdmin)


class AppointmentAdmin(admin.ModelAdmin):
    list_display=('email','full_name','phone_number','service_name','appointment_date','preferred_time')

admin.site.register(Appointment,AppointmentAdmin)

class productAdmin(admin.ModelAdmin):
    list_display=('title','image')

admin.site.register(product,productAdmin)