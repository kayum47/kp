
from django.urls import path
# from .views import display_table  # Import the display_table view
from . import views  # Import the views module


# urls.py

urlpatterns = [
    # path('display_table/', display_table, name='display_table'), --
    path('services/', views.service_list, name='service_list'),
    path('service/<int:id>/', views.bookservice, name='bookservice'),
    path('product/', views.product_list, name='product_list'),
        # Ensure this line is correct
]



