from django.db import models


class service(models.Model):
    Service_title = models.CharField(max_length=50)
    service_time = models.TimeField(null=True, blank=True)  # Ensure it's TimeField
    image = models.ImageField(upload_to='images/', default='images/default.jpg')
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)



    def __str__(self):
        return self.Service_title

   

class Appointment(models.Model):
    email = models.EmailField()
    full_name = models.CharField(max_length=100)
    phone_number = models.CharField(max_length=15)
    service_name = models.CharField(max_length=50)  # Service title, assuming from the Service model
    service_time = models.TimeField(null=True, blank=True)  # To store the service time automatically
    appointment_date = models.DateField()
    preferred_time = models.TimeField()

    def __str__(self):
        return f"{self.full_name} - {self.service_name} on {self.appointment_date} at {self.preferred_time}"
    
# srvice
class product(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to='images/')

    def __str__(self):
        return self.title