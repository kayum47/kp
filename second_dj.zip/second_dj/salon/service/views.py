from django.shortcuts import render,get_object_or_404,redirect
from .models import service,product# Import the service model,
from django.shortcuts import render, redirect  # This is correct.


# views.py
def display_table(request):
    # Logic for the function
    return render(request, 'some_template.html')


def bookservice(request, id):
    service_instance = get_object_or_404(service, id=id)
    serviceData = service.objects.all()
    data={
        "services":serviceData,
        "service":service_instance,
        "serviceid":id
    }
    return render(request, 'bookservice.html', data)


def service_list(request):
    serviceData = service.objects.all()  # Fetch all services from the database
    return render(request, 'service/service_list.html', {'serviceData': serviceData})

def create_service(request):
    if request.method == 'POST':
        # Extract data from the request, assuming you get it from a form
        service_title = request.POST.get('Service_title')
        service_time = request.POST.get('service_time')
        image = request.POST.get('image')  # Adjust based on how you handle image uploads
        
        # Create a new service entry
        service.objects.create(Service_title=service_title, service_time=service_time, image=image)
        
        return redirect('success')  # Redirect to a success page or another view

    return render(request, 'service/create_service.html')  # Render a form for creating a service
# Srvice
def product_list(request):
    productsData = product.objects.all()  # Fetch all products from the Srvice model
    return render(request, 'Product/Product.html', {'productsData': productsData})  # Ensure the key is consistent

