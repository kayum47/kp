# views.py
from django.shortcuts import render ,redirect ,get_object_or_404 
from django.contrib.auth import authenticate, logout, login 
from django.contrib import messages
from django.core.files.storage import default_storage
from django.contrib.auth.models import User
from .models import *
import random
from django.contrib.auth.decorators import login_required



def index(request):
    if request.user.is_authenticated:  # ✅ Ensure user is logged in
        try:
            user = User.objects.get(id=request.user.id)  # Get logged-in user
            profile = UserProfile.objects.get(user=user)  # Get profile
        except User.DoesNotExist:
            user = None
            profile = None
        except UserProfile.DoesNotExist:
            profile = None
    else:
        user = None
        profile = None

    context = {
        'user': user,
        'profile': profile
    }
    return render(request, 'index.html', context)


def cabavailable(request):
    if request.user.is_authenticated:  # ✅ Ensure user is logged in
        try:
            user = User.objects.get(id=request.user.id)  # Get logged-in user
            profile = UserProfile.objects.get(user=user)  # Get profile
        except User.DoesNotExist:
            user = None
            profile = None
        except UserProfile.DoesNotExist:
            profile = None
    else:
        user = None
        profile = None
    
    confirmed_cab_ids = Booking.objects.filter(status=1).values_list('cab_id', flat=True)
    cabs = Cab.objects.filter(status='Active').exclude(id__in=confirmed_cab_ids)  # Fetch only available cabs

    context = {
        'user': user,
        'profile': profile,
        'cabs': cabs
    }
    return render(request, 'cab_available.html',context)

@login_required
def book_cab(request, cab_id):
    cab = get_object_or_404(Cab, id=cab_id)
    user_profile = UserProfile.objects.filter(user=request.user).first()

    if request.method == "POST":
        pickup_zone = request.POST.get("pickup_zone")
        drop_zone = request.POST.get("drop_zone")

        ref_code = str(random.randint(100000, 999999))

        # Save booking
        Booking.objects.create(
            ref_code=ref_code,
            client=user_profile,
            cab=cab,
            pickup_zone=pickup_zone,
            drop_zone=drop_zone,
            status=0,
        )

        messages.success(request, f"Cab {cab.body_no} booked successfully!")  
        return redirect('cabavailable')  # Redirect after booking

    return render(request, "cab_available.html", {"cab": cab})


def aboutus(request):
    if request.user.is_authenticated:  # ✅ Ensure user is logged in
        try:
            user = User.objects.get(id=request.user.id)  # Get logged-in user
            profile = UserProfile.objects.get(user=user)  # Get profile
        except User.DoesNotExist:
            user = None
            profile = None
        except UserProfile.DoesNotExist:
            profile = None
    else:
        user = None
        profile = None

    context = {
        'user': user,
        'profile': profile
    }
    return render(request, 'about_us.html',context)
    
def UserLogin(request):
    error = ""
    if request.method == "POST":
        e = request.POST['uname']
        p = request.POST['pwd']
        user = authenticate(username=e, password=p)
        try:
            if user is not None:
                login(request, user)
                if user.is_superuser:
                    error = "admin"
                
                elif user.is_staff:
                    error = "driver"
                else:
                 error = "yes"
            else:
                error = "not"
        except:
            error = "not"
    d = {'error': error}
    return render(request, 'UserLogin.html',d)

@login_required
def manage_account(request):
    user = request.user
    profile, created = UserProfile.objects.get_or_create(user=user)
    error = False
    if request.method == 'POST':
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        profile.gender = request.POST.get('gender')
        profile.contact = request.POST.get('contact')
        profile.address = request.POST.get('address')

        if 'avatar' in request.FILES:
            profile.image_path = request.FILES['avatar']

        user.save()
        profile.save()
        error = True

    return render(request, 'manage_account.html', {'user': user, 'profile': profile , 'error': error})

def UserLogout(request):
    logout(request)
    return redirect('UserLogin') 

def user_bookings(request):
    user = request.user  # Get logged-in user
    profile = get_object_or_404(UserProfile, user=user)  # Ensure UserProfile exists

    # Fetch user bookings
    bookings = Booking.objects.filter(client=profile)
    error = False
    if request.method == "POST":
        booking_id = request.POST.get("booking_id")
        if booking_id:
            booking = get_object_or_404(Booking, id=booking_id)
            booking.status = 4  # ✅ Set to integer value (Cancelled)
            booking.save()
            error = True
            #messages.success(request, "Booking has been cancelled successfully.")
            #return redirect('user_bookings')
        else:
            messages.error(request, "Invalid booking ID.")
            

    return render(request, "user_booking.html", {
        "booking_list": bookings,
        "user": user,
        "profile": profile,
        "error":error
    })

def Registration(request):
    error = False
    if request.method == 'POST':
        fn = request.POST.get('fname')
        ln = request.POST.get('lname')
        un = request.POST.get('uname')
        gen = request.POST.get('gender')
        con = request.POST.get('contact')
        addr = request.POST.get('address')
        e = request.POST.get('email')
        pas = request.POST.get('password') 
        avatar = request.FILES.get('avatar')

        # Check if email already exists
        if User.objects.filter(email=e).exists():
            messages.error(request, 'This email is already registered. Please use another email.')
            return redirect('Registration')  # Redirect back to registration

        # Save image if provided
            
        user = User.objects.create_user(username=un, email=e, password=pas, first_name=fn, last_name=ln)
        profile = UserProfile.objects.create(user=user,gender=gen, address=addr, contact=con, image_path=avatar)
        if avatar:
            profile.image_path = avatar
            profile.save()
        error = True
    d = {'error': error}
    return render(request, 'Registrationform.html',d)


def dashboard (request):
    context = {
        "category_count": Category.objects.count(),
        "available_cabs": Cab.objects.filter(status='Active').count(),
        "registered_clients": UserProfile.objects.count(),
        "total_bookings": Booking.objects.count(),
        "pending_bookings": Booking.objects.filter(status=0).count(),  # Assuming 1 = Pending
        "cancelled_bookings": Booking.objects.filter(status=4).count(),  # Assuming 5 = Cancelled
        "ongoing_trips": Booking.objects.filter(status=2).count(),  # Assuming 3 = Ongoing
        "completed_trips": Booking.objects.filter(status=3).count(),  # Assuming 4 = Completed
    }
    return render(request, 'admin/dashboard.html',context)


def profile (request):
    user = request.user
    error = False
    if request.method == 'POST':
        user.first_name = request.POST.get('firstname')
        user.last_name = request.POST.get('lastname')
        password = request.POST.get('password')
        if password:  # Only update if a new password is provided
            user.set_password(password)
        user.save()
        error = True
    return render(request, 'admin/profile.html',{'user': user , 'error': error})

def categories (request):
    categories = Category.objects.all()
    error = False
    if request.method == 'POST':
        cn = request.POST.get('name')
        dcp = request.POST.get('description')
        s = request.POST.get('status')
        insert = Category.objects.create(name=cn ,description=dcp ,status=s)
        insert.save()
        error = True
    
    d = {'categories': categories, 'error': error}
    return render(request, 'admin/categories.html',d)

def update_category(request):
    error = False
    if request.method == "POST":
        category_id = request.POST.get('category_id')
        name = request.POST.get('name')
        description = request.POST.get('description')
        status = request.POST.get('status')
        #print("Updating category:", category_id)


        try:
            category = Category.objects.get(id=category_id)
            category.name = name
            category.description = description
            category.status = status
            category.save()
            error = True
            return redirect('categories')
        except Category.DoesNotExist:
            return redirect('categories')
    return render(request,{"error" :error}) 


def delete_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    category.delete()
    return redirect('categories')


def cabmanagement (request):
    cablist = Cab.objects.select_related('driver', 'category').all()  # Fetch related data to optimize queries
    return render(request, 'admin/cabmanagement.html', {'cablist': cablist})

def add_cab(request):
    error = False
    if request.method == "POST":
        category_id = request.POST.get("category_id")
        cab_reg_no = request.POST.get("cab_reg_no")
        cab_model = request.POST.get("cab_model")
        body_no = request.POST.get("body_no")
        cab_driver = request.POST.get("cab_driver")
        driver_contact = request.POST.get("driver_contact")
        driver_address = request.POST.get("driver_address")
        cab_username = request.POST.get("cab_username")
        password = request.POST.get("password")
        driver_image = request.FILES.get("img")
        status = request.POST.get("status")

        # Check if username already exists
        if User.objects.filter(username=cab_username).exists():
            messages.error(request, "Username already exists!")
            return redirect("add_cab")

        # Create the user with is_staff=True
        user = User.objects.create_user(
            username=cab_username,
            password=password,
            first_name=cab_driver
        )
        user.is_staff = True  # Make the cab driver a staff member
        user.save()
        error = True

        # Save the uploaded image
        if driver_image:
            image_path = default_storage.save(f"drivers/{driver_image.name}", driver_image)
        else:
            image_path = "default.png"

        # Create the cab entry
        category = Category.objects.get(id=category_id)
        Cab.objects.create(
            category=category,
            cab_reg_no=cab_reg_no,
            cab_model=cab_model,
            body_no=body_no,
            driver=user,
            driver_contact=driver_contact,
            driver_address=driver_address,
            driver_image=image_path,
            status=status
        )
        return redirect("cabmanagement")

    categories = Category.objects.all()
    return render(request, "admin/add_cab.html", {"categories": categories,'error':error})

@login_required
def delete_cab(request, cab_id):
    cab = get_object_or_404(Cab, id=cab_id)

    # Check if the cab has an associated driver
    if cab.driver:
        user = cab.driver
        cab.delete()  # Delete the cab first
        user.delete()  # Delete the driver (User account) 

    return redirect('cabmanagement')

@login_required
def edit_cab(request, cab_id):
    cab = get_object_or_404(Cab, id=cab_id)
    
    if request.method == "POST":
        cab.category = get_object_or_404(Category, id=request.POST['category'])
        cab.cab_reg_no = request.POST['cab_reg_no']
        cab.cab_model = request.POST['cab_model']
        cab.body_no = request.POST['body_no']
        cab.driver = get_object_or_404(User, id=request.POST['driver'])
        cab.driver_contact = request.POST['driver_contact']
        cab.driver_address = request.POST['driver_address']

        if 'driver_image' in request.FILES:
            cab.driver_image = request.FILES['driver_image']

        cab.status = request.POST['status']
        password = request.POST.get('password')  # Get password from the form
        if password:  # Only update if a new password is provided
            cab.driver.set_password(password)
            cab.driver.save()
        cab.save()
        
        return redirect('cabmanagement')  # Redirect back to the list page after editing

    categories = Category.objects.all()
    drivers = User.objects.all()
    
    return render(request, 'admin/edit_cab.html', {'cab': cab, 'categories': categories, 'drivers': drivers})

def clients_list(request):
    clilist = UserProfile.objects.select_related('user').filter(user__is_superuser=False ,user__is_staff =False)
    return render(request, 'admin/clients_list.html',{'clilist':clilist})

@login_required
def edit_user(request, user_id):
    user = get_object_or_404(User, id=user_id)
    user_profile, created = UserProfile.objects.get_or_create(user=user)

    if request.method == "POST":
        # Get form data
        first_name = request.POST.get("fname")
        last_name = request.POST.get("lname")
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        gender = request.POST.get("gender")
        contact = request.POST.get("contact")
        address = request.POST.get("address")
        avatar = request.FILES.get("avatar")

        # Update User model
        user.first_name = first_name
        user.last_name = last_name
        user.username = username
        user.email = email

        if password:  # Only update password if a new one is provided
            user.set_password(password)

        user.save()

        # Update UserProfile model
        user_profile.gender = gender
        user_profile.contact = contact
        user_profile.address = address

        if avatar:
            user_profile.image_path = avatar  # Save new avatar if uploaded

        user_profile.save()

        messages.success(request, "User profile updated successfully!")
        return redirect("clients_list")  # Redirect to the user list page

    return render(request, "admin/edit_user.html", {"user": user, "user_profile": user_profile})
@login_required
def delete_client(request, client_id):
    user = get_object_or_404(User, id=client_id)
    user.delete()
    messages.success(request, "Client deleted successfully.")
    return redirect('clients_list') 

def list_bookings(request):
    bookings = Booking.objects.all()
    return render(request, 'admin/booking_list.html', {'booking_list': bookings})

@login_required
def driver_dashboard(request):
    user = request.user
    
    # Ensure the driver has a cab assigned
    cab, created = Cab.objects.get_or_create(driver=user)
    
    # Fetch bookings related to the driver's cab
    bookings = Booking.objects.filter(cab=cab)

    return render(request, "driver/driver_dashboard.html", {"booking_list": bookings, "user": user, "cab": cab})

def update_booking_status(request, booking_id):
    user = request.user
    
    # Ensure the driver has a cab assigned
    cab, created = Cab.objects.get_or_create(driver=user)
    booking = get_object_or_404(Booking, id=booking_id)
    error = "not"
    if request.method == "POST":
        new_status = request.POST.get("status")
        if new_status == "confirmed":
            booking.status = 1  # Confirmed
            error ="confirmed"
        elif new_status == "picked":
            booking.status = 2  # Picked Up
            error ="pickedup"
        elif new_status == "dropped":
            booking.status = 3  # Dropped Off
            error ="dropped"
        booking.save()
        #return redirect("driver_dashboard")  # Redirect to booking list

    return render(request, "driver/update_booking.html", {"booking": booking,"user": user, "cab": cab,"error":error})

def manage_driver_account(request):
    user = request.user
    cab, created = Cab.objects.get_or_create(driver=user)
    error = False
    if request.method == 'POST':
        user.first_name = request.POST.get('first_name')
        cab.driver_contact = request.POST.get('contact')
        cab.driver_address = request.POST.get('address')

        if 'avatar' in request.FILES:
            cab.driver_image = request.FILES['avatar']
        user.save()
        cab.save()
        error = True
    return render(request, 'driver/manage_driver_account.html',{'user': user, 'cab': cab , 'error': error})