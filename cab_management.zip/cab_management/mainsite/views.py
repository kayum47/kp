# views.py
from django.shortcuts import render ,redirect ,get_object_or_404
from django.contrib.auth import authenticate, logout, login 
from django.contrib import messages
from django.core.files.storage import default_storage
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth.decorators import login_required



def index(request):
    if request.user.is_authenticated:  # ✅ Ensure user is logged in
        try:
            user = User.objects.get(id=request.user.id)  # Get logged-in user
            profile = UserProfile.objects.get(user=user)  # Get profile
        except User.DoesNotExist:
            user = None
            profile = None
        except UserProfile.DoesNotExist:
            profile = None
    else:
        user = None
        profile = None

    context = {
        'user': user,
        'profile': profile
    }
    return render(request, 'index.html', context)


def cabavailable(request):
    if request.user.is_authenticated:  # ✅ Ensure user is logged in
        try:
            user = User.objects.get(id=request.user.id)  # Get logged-in user
            profile = UserProfile.objects.get(user=user)  # Get profile
        except User.DoesNotExist:
            user = None
            profile = None
        except UserProfile.DoesNotExist:
            profile = None
    else:
        user = None
        profile = None

    context = {
        'user': user,
        'profile': profile
    }
    return render(request, 'cab_available.html',context)


def aboutus(request):
    if request.user.is_authenticated:  # ✅ Ensure user is logged in
        try:
            user = User.objects.get(id=request.user.id)  # Get logged-in user
            profile = UserProfile.objects.get(user=user)  # Get profile
        except User.DoesNotExist:
            user = None
            profile = None
        except UserProfile.DoesNotExist:
            profile = None
    else:
        user = None
        profile = None

    context = {
        'user': user,
        'profile': profile
    }
    return render(request, 'about_us.html',context)
    
def UserLogin(request):
    error = ""
    if request.method == "POST":
        e = request.POST['uname']
        p = request.POST['pwd']
        user = authenticate(username=e, password=p)
        try:
            if user is not None:
                login(request, user)
                if user.is_superuser:
                    error = "admin"# Check if the user is a superuser
                    #return redirect('admin_dashboard')
                    # Redirect superusers to admin page
                else:
                 error = "yes"
            else:
                error = "not"
        except:
            error = "not"
    d = {'error': error}
    return render(request, 'UserLogin.html',d)

@login_required
def manage_account(request):
    user = request.user
    profile, created = UserProfile.objects.get_or_create(user=user)
    error = False
    if request.method == 'POST':
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')
        profile.gender = request.POST.get('gender')
        profile.contact = request.POST.get('contact')
        profile.address = request.POST.get('address')

        if 'avatar' in request.FILES:
            profile.image_path = request.FILES['avatar']

        user.save()
        profile.save()
        error = True

    return render(request, 'manage_account.html', {'user': user, 'profile': profile , 'error': error})

def DriverLogin(request):
    return render(request, 'DriverLogin.html')

def UserLogout(request):
    logout(request)
    return redirect('UserLogin') 

def Registration(request):
    error = False
    if request.method == 'POST':
        fn = request.POST.get('fname')
        ln = request.POST.get('lname')
        un = request.POST.get('uname')
        gen = request.POST.get('gender')
        con = request.POST.get('contact')
        addr = request.POST.get('address')
        e = request.POST.get('email')
        pas = request.POST.get('password') 
        avatar = request.FILES.get('avatar')

        # Check if email already exists
        if User.objects.filter(email=e).exists():
            messages.error(request, 'This email is already registered. Please use another email.')
            return redirect('Registration')  # Redirect back to registration

        # Save image if provided
            
        user = User.objects.create_user(username=un, email=e, password=pas, first_name=fn, last_name=ln)
        profile = UserProfile.objects.create(user=user,gender=gen, address=addr, contact=con, image_path=avatar)
        if avatar:
            profile.image_path = avatar
            profile.save()
        error = True
    d = {'error': error}
    return render(request, 'Registrationform.html',d)


def dashboard (request):
    return render(request, 'admin/dashboard.html')


def profile (request):
    user = request.user
    error = False
    if request.method == 'POST':
        user.first_name = request.POST.get('firstname')
        user.last_name = request.POST.get('lastname')
        user.password = request.POST.get('password')

        user.save()
        error = True
    return render(request, 'admin/profile.html',{'user': user , 'error': error})

def categories (request):
    categories = Category.objects.all()
    error = False
    if request.method == 'POST':
        cn = request.POST.get('name')
        dcp = request.POST.get('description')
        s = request.POST.get('status')
        insert = Category.objects.create(name=cn ,description=dcp ,status=s)
        insert.save()
        error = True
        #return redirect('categories')
    d = {'categories': categories, 'error': error}
    return render(request, 'admin/categories.html',d)

def update_category(request, category_id):  # Expect category_id in URL
    category = get_object_or_404(Category, id=category_id)

    if request.method == 'POST':
        category.name = request.POST.get('name')
        category.description = request.POST.get('description')
        category.status = request.POST.get('status')
        category.save()
        return redirect('categories')

    return render(request, 'admin/update_category.html', {'category': category})


def delete_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    category.delete()
    return redirect('categories')


def cabmanagement (request):
    return render(request, 'admin/cabmanagement.html')