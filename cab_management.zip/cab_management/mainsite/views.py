from django.shortcuts import render ,HttpResponse

# Create your views here.

def index(request):
    return render(request ,'index.html')
    #return HttpResponse("hello , this is home page")

def cabavailable(request):
    return render(request ,'cab_available.html')
    #return HttpResponse("hello , this is home page")

def aboutus(request):
    return render(request ,'about_us.html')
    #return HttpResponse("hello , this is about page")
    
def UserLogin(request):
    return render(request ,'UserLogin.html')

def DriverLogin(request):
    return render(request ,'DriverLogin.html')

def Registration(request):
    return render(request ,'Registrationform.html')