from django.db import models
import uuid
from django.contrib.auth.models import User
from django.utils.timezone import now 

# Create your models here.

class UserProfile(models.Model):

    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other')
    ]
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    address = models.CharField(max_length=50, null=True)
    contact = models.CharField(max_length=10, null=True)
    image_path = models.ImageField(upload_to='avatars/', blank=True, null=True)
    
    def __str__(self):
        return self.user.username
    

class Category(models.Model):
    STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Inactive', 'Inactive'),
    ]
    
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Active')
    

    def __str__(self):
        return self.name


class Cab(models.Model):
    STATUS_CHOICES = [
        ('Active', 'Active'),
        ('Inactive', 'Inactive'),
    ]
    
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    cab_reg_no = models.CharField(max_length=255, unique=True)
    cab_model = models.CharField(max_length=255)
    body_no = models.CharField(max_length=255, unique=True)
    driver = models.ForeignKey(User, on_delete=models.CASCADE)
    driver_contact = models.CharField(max_length=15)
    driver_address = models.TextField()
    driver_image = models.ImageField(upload_to='drivers/')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Active')

    def __str__(self):
        return f"{self.cab_reg_no} - {self.cab_model}"

class Booking(models.Model):
    STATUS_CHOICES = [
        (0, "Pending"),
        (1, "Confirmed"),
        (2, "Picked-up"),
        (3, "Dropped off"),
        (4, "Cancelled"),
    ]

    ref_code = models.CharField(max_length=6, unique=True)
    client = models.ForeignKey('UserProfile', on_delete=models.CASCADE)  # Client from UserProfile
    cab = models.ForeignKey('Cab', on_delete=models.CASCADE)  # ForeignKey to Cab
    pickup_zone = models.TextField()  # Pickup Location
    drop_zone = models.TextField()  # Drop-off Location
    status = models.IntegerField(choices=STATUS_CHOICES, default=0)  # Booking Status
    booking_date = models.DateTimeField(auto_now_add=True)  # Created At
    updated_date = models.DateTimeField(auto_now=True)  # Last Updated

    def __str__(self):
        return f"Booking {self.ref_code} - {self.client.user.username} ({self.get_status_display()})"