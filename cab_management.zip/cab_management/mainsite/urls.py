from django.conf import settings
from django.urls import path ,include
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('', views.index, name='Home'),
    path('cabavailable/', views.cabavailable, name='Cabavailable'), 
    path('aboutus/', views.aboutus, name='AboutUs'),
    path('UserLogin/', views.UserLogin, name='UserLogin'),
    path('logout/', views.UserLogout, name='UserLogout'),
    path('manage_account/', views.manage_account, name='manage_account'),
    path('Registration/', views.Registration, name='Registration'),
    path('DriverLogin/', views.DriverLogin, name='DriverLogin'),
    path('admin_dashboard/',views.dashboard,name='dashboard'),
    path('profile/', views.profile,name='profile'),
    path('categories/', views.categories,name='categories'),
    path('categories/delete/<int:category_id>/', views.delete_category, name='delete_category'),
    path('categories/update/<int:category_id>/', views.update_category, name='update_category'),
    path('cabmanagement/', views.cabmanagement,name='cabmanagement'),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
