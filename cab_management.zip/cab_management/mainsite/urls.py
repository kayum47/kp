from django.conf import settings
from django.urls import path ,include
from django.conf.urls.static import static
from . import views

urlpatterns = [
    path('', views.index, name='Home'),
    path('cabavailable/', views.cabavailable, name='cabavailable'),
    path('cabavailable/book_cab/<int:cab_id>/', views.book_cab, name='book_cab'), 
    path('aboutus/', views.aboutus, name='AboutUs'),
    path('UserLogin/', views.UserLogin, name='UserLogin'),
    path('logout/', views.UserLogout, name='UserLogout'),
    path('manage_account/', views.manage_account, name='manage_account'),
    path('user_bookings/', views.user_bookings, name='user_bookings'),
    path('Registration/', views.Registration, name='Registration'),

    path('admin_dashboard/',views.dashboard,name='dashboard'),
    path('profile/', views.profile,name='profile'),
    path('categories/', views.categories,name='categories'),
    path('categories/delete/<int:category_id>/', views.delete_category, name='delete_category'),
    path('categories/update_category', views.update_category, name='update_category'),
    path('cabmanagement/', views.cabmanagement,name='cabmanagement'),
    path('add_cab/', views.add_cab,name='add_cab'),
    path('delete_cab/<int:cab_id>/', views.delete_cab, name='delete_cab'),
    path('edit_cab/<int:cab_id>/', views.edit_cab, name='edit_cab'),
    path('clients_list/', views.clients_list,name='clients_list'),
    path('edit_user/<int:user_id>/', views.edit_user, name='edit_user'),
    path('delete_client/<int:client_id>/',views.delete_client, name='delete_client'),
    path('list_bookings/', views.list_bookings, name='list_bookings'),
    path('driver_dashboard/', views.driver_dashboard,name='driver_dashboard'),
    path('manage_driver_account/', views.manage_driver_account,name='manage_driver_account'),
    path("booking/update/<int:booking_id>/", views.update_booking_status, name="update_booking_status"),
]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
