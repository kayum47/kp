import calendar
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404
from administrator.models import Teacher, TeacherAttendance

@login_required(login_url='login:login')
def teacher_dashboard(request):
    # Fetch the teacher's profile
    teacher = get_object_or_404(Teacher, user=request.user)

    # Get the current date
    current_date = timezone.now()
    current_year = current_date.year
    current_month = current_date.month

    # Get selected year and month from POST data, or use current values
    if request.method == 'POST':
        selected_year = int(request.POST.get('year', current_year))
        selected_month = int(request.POST.get('month', current_month))
    else:
        selected_year = current_year
        selected_month = current_month

    # Get all attendance records for the selected year and month
    attendance_records = TeacherAttendance.objects.filter(
        teacher=teacher,
        date__year=selected_year,
        date__month=selected_month
    )

    # Get month name for display
    current_month_name = calendar.month_name[selected_month]

    # Generate a list of years for the dropdown (e.g., 2020 to current year)
    years = list(range(current_year - 5, current_year + 1))  # Adjust the range as needed

    return render(request, 'teacher_dashboard.html', {
        'teacher': teacher,
        'attendance_records': attendance_records,
        'current_month': current_month_name,  # Get month name
        'months': list(calendar.month_name)[1:],  # List of months for the dropdown
        'years': years,  # List of years for the dropdown
        'selected_month': selected_month,  # Selected month for the form
        'selected_year': selected_year,  # Selected year for the form
    })

#student att

from django.shortcuts import render, redirect
from .forms import StandardForm
from administrator.models import Student, StudentAttendance, Standard, AcademicYear
from datetime import datetime

@login_required(login_url='login:login')
def student_attendance_view(request):
    selected_standard = None
    students = None
    attendance_records = None  # To store attendance records for updating
    current_date = datetime.now().date()  # Get the current date

    # If the form is submitted
    if request.method == 'POST':
        standard_form = StandardForm(request.POST)

        # Handle standard selection
        if 'select_standard' in request.POST and standard_form.is_valid():
            selected_standard = standard_form.cleaned_data['standard']
            students = Student.objects.filter(standard=selected_standard)
            # Fetch attendance records for the selected standard
            academic_year = AcademicYear.objects.get(is_active=True)
            attendance_records = StudentAttendance.objects.filter(student__standard=selected_standard, academic_year=academic_year)

        # Handle attendance submission
        elif 'submit_attendance' in request.POST:
            academic_year = AcademicYear.objects.get(is_active=True)
            date = request.POST['date']
            if datetime.strptime(date, '%Y-%m-%d').date() > current_date:
                # Handle the case where the selected date is greater than the current date
                # You can add an error message or redirect to an error page
                return render(request, 'student_attendance.html', {'error_message': 'You cannot select a date greater than the current date'})
            if StudentAttendance.objects.filter(academic_year=academic_year, date=date).exists():
                # Handle the case where attendance has already been added for the selected date
                return render(request, 'student_attendance.html', {'error_message': 'Attendance has already been added for this date'})
            standard_id = request.POST['selected_standard']  # Preserve the selected standard

            selected_standard = Standard.objects.get(id=standard_id)
            students = Student.objects.filter(standard=selected_standard)

            for key, value in request.POST.items():
                if key.startswith('status_'):
                    student_id = key.split('_')[1]
                    student = Student.objects.get(id=student_id)
                    status = value
                    attendance, created = StudentAttendance.objects.get_or_create(
                        student=student,
                        date=date,
                        academic_year=academic_year
                    )
                    attendance.status = status
                    attendance.save()

            return redirect('teacher:view_student_attendance')  # Redirect after saving attendance

        # Reset standard selection if the user clicks the "Change Standard" button
        elif 'change_standard' in request.POST:
            standard_form = StandardForm()
            selected_standard = None
            students = None

    else:
        standard_form = StandardForm()

    return render(request, 'student_attendance.html', {
        'standard_form': standard_form,
        'students': students,
        'selected_standard': selected_standard,
        'attendance_records': attendance_records,  # Include attendance records for updating
        'current_date': current_date  # Pass the current date to the template
    })

from django.shortcuts import render
from administrator.models import StudentAttendance, Standard, Student
from .forms import StandardForm
from django.db.models import Q
from datetime import datetime

@login_required(login_url='login:login')
def view_student_attendance(request):
    selected_standard = None
    selected_date = None
    attendance_records = None
    current_date = datetime.now().date()

    if request.method == 'POST':
        standard_form = StandardForm(request.POST)
        
        # Get selected date
        date_string = request.POST.get('date', current_date)
        selected_date = datetime.strptime(date_string, '%Y-%m-%d').date()

        # When the user selects the standard
        if 'select_standard' in request.POST and standard_form.is_valid():
            selected_standard = standard_form.cleaned_data['standard']
            # Filter attendance records by selected standard and date
            attendance_records = StudentAttendance.objects.filter(
                student__standard=selected_standard,
                date=selected_date
            )

    else:
        standard_form = StandardForm()
        selected_date = current_date  # Set default date to current date

    return render(request, 'view_student_attendance.html', {
        'standard_form': standard_form,
        'attendance_records': attendance_records,
        'selected_standard': selected_standard,
        'selected_date': selected_date,
    })



from django.shortcuts import render, redirect, get_object_or_404
from administrator.models import StudentAttendance
from .forms import rewriteAttendanceForm

@login_required(login_url='login:login')
def rewrite_student_attendance(request, pk):
    attendance = get_object_or_404(StudentAttendance, pk=pk)
    if request.method == 'POST':
        form = rewriteAttendanceForm(request.POST, instance=attendance)
        if form.is_valid():
            form.save()
            return redirect('teacher:view_student_attendance')
    else:
        form = rewriteAttendanceForm(instance=attendance)
    return render(request, 'rewrite_student_attendance.html', {'form': form})