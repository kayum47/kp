from django import forms
from administrator.models import Standard, StudentAttendance

class StandardForm(forms.Form):
    standard = forms.ModelChoiceField(queryset=Standard.objects.all(), label="Select Standard", required=True)

class StudentAttendanceForm(forms.ModelForm):
    class Meta:
        model = StudentAttendance
        fields = ['date', 'status', 'academic_year']
        widgets = {
            'date': forms.SelectDateWidget(),
            'status': forms.RadioSelect(choices=[('Present', 'Present'), ('Absent', 'Absent')]),
        }


from django import forms
from administrator.models import StudentAttendance

class rewriteAttendanceForm(forms.ModelForm):
    class Meta:
        model = StudentAttendance
        fields = ('status',)