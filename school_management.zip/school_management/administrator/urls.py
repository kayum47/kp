from django.urls import path
from . import views

app_name= "administrator"

urlpatterns = [
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('add-teacher/', views.add_teacher, name='add_teacher'),
    path('manage-teacher/', views.manage_teacher, name='manage_teacher'),
    path('update-teacher/<int:teacher_id>/',views.update_teacher, name='update_teacher'),
    path('add-standard/', views.add_standard, name='add_standard'),
    path('add-subject/', views.add_subject, name='add_subject'),
    path('update-subject/<int:subject_id>/', views.update_subject, name='update_subject'),
    path('delete-subject/<int:subject_id>/', views.delete_subject, name='delete_subject'),
    path('add-student/', views.add_student, name='add_student'),
    path('manage-student/', views.manage_student, name='manage_student'),
    path('update-student/<int:student_id>/', views.update_student, name='update_student'),
    path('teacher-attendance/', views.teacher_attendance, name='teacher_attendance'),
    path('view-attendance/', views.view_attendance, name='view_attendance'),
    path('update-attendance/<int:record_id>/', views.update_attendance, name='update_attendance'),
    path('delete-attendance/<int:record_id>/', views.delete_attendance, name='delete_attendance'),
    path('add-teacher-subject/', views.add_teacher_subject, name='add_teacher_subject'),
    path('manage-teacher-subject/', views.manage_teacher_subject, name='manage_teacher_subject'),
    path('student_attendance_view1/', views.student_attendance_view1, name='student_attendance_view1'),
]
