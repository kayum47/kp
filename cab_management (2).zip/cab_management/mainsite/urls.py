from django.contrib import admin
from django.urls import path , include
from mainsite import views


urlpatterns = [
    path("",views.index, name='Home'),
    path("cabavailable/",views.cabavailable, name='Cab_available'),
    path("aboutus/",views.aboutus, name='About Us'),
    path("UserLogin/",views.UserLogin, name='UserLogin'),
    path("doLogin/",views.doLogin, name='doLogin'),
    path('logout/', views.UserLogout, name='UserLogout'),
    path("Registration",views.Registration, name='Registration'),
    path("DriverLogin",views.DriverLogin, name='DriverLogin'),
    
]
