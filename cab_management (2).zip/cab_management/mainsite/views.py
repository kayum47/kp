
from django.contrib import messages
from django.contrib.messages.storage.fallback import FallbackStorage
from django.shortcuts import render, redirect
from .models import ClientList
from django.core.files.storage import default_storage
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, login, logout

# Create your views here.

def index(request):
    return render(request ,'index.html')
    #return HttpResponse("hello , this is home page")

def cabavailable(request):
    return render(request ,'cab_available.html')
    #return HttpResponse("hello , this is home page")

def aboutus(request):
    return render(request ,'about_us.html')
    #return HttpResponse("hello , this is about page")
    
def UserLogin(request):
    
    return render(request, 'UserLogin.html')

def doLogin(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Authenticate user
        user = authenticate(request, username=email, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect('/')  # Redirect to homepage or dashboard
        else:
            messages.error(request, "Invalid email or password. Please try again.")
            return redirect('UserLogin')  # Redirect back to login page with error message

    return render(request, 'UserLogin.html')

def UserLogout(request):
    logout(request)
    return redirect('UserLogin')  # Redirect to login page

def DriverLogin(request):
    return render(request ,'DriverLogin.html')

def Registration(request):
    # CLEAR OLD MESSAGES
    storage = messages.get_messages(request)
    storage.used = True  # This prevents showing old messages when revisiting the page

    if request.method == 'POST':
        fullname = request.POST.get('fullname')
        gender = request.POST.get('gender')
        contact = request.POST.get('contact')
        address = request.POST.get('address')
        email = request.POST.get('email')
        password = make_password(request.POST.get('password'))  # Hash password
        avatar = request.FILES.get('avatar')

        # Check if email already exists
        if ClientList.objects.filter(email=email).exists():
            messages.error(request, 'This email is already registered. Please use another email.')
            return redirect('Registration')  # Redirect back to registration

        # Save image if provided
        image_path = None
        if avatar:
            image_path = default_storage.save(f'avatars/{avatar.name}', avatar)

        # Create new user
        client = ClientList(
            fullname=fullname,
            gender=gender,
            contact=contact,
            address=address,
            email=email,
            password=password,
            image_path=image_path
        )
        client.save()

        messages.success(request, 'Registration successful! You can now log in.')
        return redirect('UserLogin')  # Redirect to login

    return render(request, 'Registrationform.html')