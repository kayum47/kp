from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.db import models
from django.utils import timezone

class ClientListManager(BaseUserManager):
    def get_by_natural_key(self, username):
        # Look up the user by the field defined in USERNAME_FIELD (e.g., email)
        return self.get(**{self.model.USERNAME_FIELD: username})

    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError("The Email field must be set")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        if extra_fields.get('is_staff') is not True:
            raise ValueError('Superuser must have is_staff=True.')
        if extra_fields.get('is_superuser') is not True:
            raise ValueError('Superuser must have is_superuser=True.')
        return self.create_user(email, password, **extra_fields)





class ClientList(AbstractBaseUser, PermissionsMixin):
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other')
    ]
    
    fullname = models.TextField()
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    contact = models.TextField()
    address = models.TextField()
    email = models.EmailField(max_length=100, unique=True)
    password = models.TextField()
    image_path = models.TextField(blank=True, null=True)
    date_created = models.DateTimeField(auto_now_add=True)
    date_added = models.DateTimeField(auto_now=True)
    
    USERNAME_FIELD = 'email'
    # REQUIRED_FIELDS should be a list of required fields besides USERNAME_FIELD.
    REQUIRED_FIELDS = []  # or e.g., ['first_name', 'last_name']

    def __str__(self):
        return self.email