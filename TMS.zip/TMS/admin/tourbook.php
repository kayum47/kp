<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tour Package Booking</title>
    <link rel="stylesheet" href="">
    <style>
        * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
}

.container {
    max-width: 600px;
    margin: 20px auto;
    padding: 20px;
    background: white;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

label {
    display: block;
    margin-top: 10px;
}

input, select, button {
    width: 100%;
    padding: 12px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    background-color: #28a745;
    color: white;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button:hover {
    background-color: #218838;
}

/* Responsive Design */
@media (max-width: 600px) {
    .container {
        margin: 10px;
        padding: 15px;
    }
    
    h1 {
        font-size: 1.5em;
    }

    input, select, button {
        padding: 10px;
    }
}

    </style>
<body>
    <div class="container">
        <h1>Book Your Tour Package</h1>
        <form action="tourbooking.php" method="POST">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="package">Select Package:</label>
            <select id="package" name="package" required>
                <option value="Beach Vacation">Beach Vacation</option>
                <option value="Mountain Trek">Mountain Trek</option>
                <option value="City Tour">City Tour</option>
            </select>

            <label for="booking_date">Booking Date:</label>
            <input type="date" id="booking_date" name="booking_date" required>

            <button type="submit">Submit Booking</button>
        </form>
    </div>
</body>
</html>
