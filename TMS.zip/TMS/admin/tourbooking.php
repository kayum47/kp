<?php
include("config.php");

if (isset($_GET['confirm_id'])) {
    $confirm_id = $_GET['confirm_id'];
    $sql = "UPDATE bookings SET status = 'confirmed' WHERE id = $confirm_id";
    $conn->query($sql);
    echo "<script>alert('Booking Confirmed'); window.location.href='admin_bookings.php';</script>";
}

if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM bookings WHERE id = $delete_id";
    $conn->query($sql);
    echo "<script>alert('Booking Deleted'); window.location.href='admin_bookings.php';</script>";
}

// Fetch all bookings
$sql = "SELECT bookings.*, packages.location FROM bookings INNER JOIN packages ON bookings.package_id = packages.id WHERE bookings.status = 'pending'";
$result = $conn->query($sql);
?>

<?php
include("config.php");

if (isset($_GET['confirm_id'])) {
    $confirm_id = $_GET['confirm_id'];
    $sql = "UPDATE bookings SET status = 'confirmed' WHERE id = $confirm_id";
    $conn->query($sql);
    echo "<script>alert('Booking Confirmed'); window.location.href='admin_bookings.php';</script>";
}

if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM bookings WHERE id = $delete_id";
    $conn->query($sql);
    echo "<script>alert('Booking Deleted'); window.location.href='admin_bookings.php';</script>";
}

// Fetch all bookings
$sql = "SELECT bookings.*, packages.location FROM bookings INNER JOIN packages ON bookings.package_id = packages.id WHERE bookings.status = 'pending'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Bookings</title>
    <style>
        body {
            font-family: Arial, sans-serif; /* Set a default font */
            background-color: #f0f2f5; /* Light background color for the page */
            margin: 0; /* Reset default margin */
        }

        .main-container {
            margin: 25px 20px 0px 280px;
            max-width: 1200px; /* Maximum width of the main container */
           
            padding: 20px; /* Padding inside the container */
            background-color: #fff; /* White background for the main container */
            border-radius: 5px; /* Rounded corners */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
        }

        h1 {
            margin-bottom: 20px; /* Space below the heading */
            color: #333; /* Dark color for the heading */
            text-align: center; /* Center the heading */
        }

        .booking-table-container {
            border: 1px solid #ddd; /* Border around the booking table container */
            padding: 20px; /* Padding around the table */
            border-radius: 5px; /* Rounded corners */
            background-color: #fff; /* White background color for the table container */
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); /* Subtle shadow effect */
        }

        .table {
            width: 100%; /* Full width table */
            margin: 0; /* Reset margin */
            border-collapse: collapse; /* Collapse borders */
        }

        .table th, .table td {
            text-align: center; /* Center align text in table cells */
            vertical-align: middle; /* Vertically center text */
            padding: 10px; /* Padding inside table cells */
        }

        .table th {
            background-color: #007bff; /* Bootstrap primary color */
            color: white; /* White text for the header */
        }

        .table td {
            border: 1px solid #ddd; /* Border around table cells */
        }

        .btn {
            margin: 5px; /* Margin around buttons */
            text-decoration: none; /* Remove underline from links */
            color: white; /* White text for buttons */
            padding: 5px 10px; /* Padding for buttons */
            border-radius: 3px; /* Rounded corners for buttons */
        }

        .btn-success {
            background-color: #28a745; /* Success button color */
        }

        .btn-danger {
            background-color: #dc3545; /* Danger button color */
        }
    </style>
</head>

<body>
    <?php include('index.php'); ?>
    <div class="main-container">
        <h1>Pending Bookings</h1>
        <div class="booking-table-container">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Package</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "
                            <tr>
                                <td>" . $row['id'] . "</td>
                                <td>" . $row['location'] . "</td>
                                <td>" . $row['name'] . "</td>
                                <td>" . $row['email'] . "</td>
                                <td>" . $row['phone'] . "</td>
                                <td>" . ucfirst($row['status']) . "</td>
                                <td>
                                    <a href='tourbooking.php?confirm_id=" . $row['id'] . "' class='btn btn-success'>Confirm</a>
                                    <a href='tourbooking.php?delete_id=" . $row['id'] . "' class='btn btn-danger'>Delete</a>
                                </td>
                            </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>No bookings found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
