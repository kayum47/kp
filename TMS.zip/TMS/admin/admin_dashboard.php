<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            box-sizing: border-box;
        }

        .container {
            margin: 25px 20px 0px 280px;
            max-width: 1200px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            
            
        }

        /* Title Style */
        .title {
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            text-align: left;
            margin-bottom: 20px;
            margin-top: 5px;
        }

        .dashboard {
            display: grid;
            grid-template-columns: repeat(3, minmax(280px, 1fr));
            gap: 20px;
            width: 100%;
        }

        .card {
            background-color: #2e5b8f;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            color: white;
            text-align: center;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            position: relative;
            height: 150px;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: scale(1.05);
        }

        .card h2 {
            margin: 0;
            font-size: 2.5rem;
        }

        .card .text-icon {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .card p {
            margin: 10px 10px 10px 0;
            font-size: 1.2rem;
        }

        .card i {
            font-size: 1.5rem;
            margin-left: 10px;
        }

        .card a {
            color: white;
            text-decoration: none;
            margin-top: 10px;
            font-weight: bold;
        }

        .card a .fas {
            margin-left: 5px;
        }

        /* Button style */
        .card button {
            margin-top: 15px;
            font-weight: bold;
            background-color: white;
            color: #333;
            padding: 10px 0;
            width: 100%;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .card button:hover {
            background-color: #e0e0e0;
        }

        /* Color themes for cards */
        .card.blue {
            background-color: #2e5b8f;
        }

        .card.green {
            background-color: #6fbf5f;
        }

        .card.light-blue {
            background-color: #29a9e0;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .dashboard {
                grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            }

            .card {
                height: auto;
                padding: 20px;
            }
        }

        @media (max-width: 480px) {
            .title {
                font-size: 1.5rem;
            }

            .card h2 {
                font-size: 2rem;
            }

            .card p {
                font-size: 1rem;
            }
        }

    </style>
</head>
<body>
    <?php include('index.php'); ?>

    <div class="container">
        <h1 class="title">Dashboard</h1>

        <div class="dashboard">
            <div class="card blue">
                <h2>150</h2>
                <div class="text-icon">
                    <p>Member</p>
                    <i class="fas fa-user"></i>
                </div>
                <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>

            <div class="card green">
                <h2>200</h2>
                <div class="text-icon">
                    <p>Client</p>
                    <i class="fas fa-users"></i>
                </div>
                <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>

            <div class="card light-blue">
                <h2>75</h2>
                <div class="text-icon">
                    <p>Tour</p>
                    <i class="fas fa-bus"></i>
                </div>
                <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>

            <div class="card light-blue">
                <h2>50</h2>
                <div class="text-icon">
                    <p>Booking</p>
                    <i class="fas fa-pencil-alt"></i>
                </div>
                <a href="#" class="more-info">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
        </div>
    </div>

    <!-- Font Awesome Icons CDN -->
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>
