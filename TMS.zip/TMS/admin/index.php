<html></html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .sidebar {
            margin-top: 50px;
            width: 250px;
            height: 100vh;
            background-color: #2c3e50;
            position: fixed;
            top: 0;
            left: 0;
            color: #ecf0f1;
            padding-top: 20px;
        }
        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            padding: 15px;
            text-align: left;
            padding-left: 20px;
        }
        .sidebar ul li:hover {
            background-color: #34495e;
            cursor: pointer;
        }
        .sidebar ul li ul {
            display: none;
            list-style: none;
            padding: 0;
        }
        .sidebar ul li:hover ul {
            display: block;
        }
        .sidebar ul li ul li {
            padding: 10px;
            padding-left: 40px;
            background-color: #34495e;
        }
        .brand {
            background-color: #2c3e50;
            padding: 2px 36px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: #fff;
            position: fixed; /* Makes the navbar fixed */
            top: 0; /* Positions it at the top */
            left: 0;
            right: 0;
            z-index: 1000; /* Ensures it stays above other content */
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Add padding to the body to avoid content being hidden behind the navbar */
        body {
            padding-top: 50px; /* Adjust according to the navbar height */
        }

        /* Profile Navigation */
        .ts-profile-nav {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            background-color: black;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .ts-profile-nav li {
            position: relative;
        }

        .ts-profile-nav li a {
            display: flex;
            align-items: center;
            padding: 8px 26px;
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        .ts-profile-nav li a:hover {
            color: #fff;
            background-color: red;
        }

        .ts-profile-nav .ts-avatar {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            margin-right: 8px;
        }

        .ts-profile-nav .ts-account ul {
            display: none;
            position: absolute;
            top: 100%;
            right: 0;
            background-color: black;
            list-style: none;
            margin: 0;
            padding: 0;
            min-width: 175px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }

        .ts-profile-nav .ts-account ul li {
            border-bottom: 1px solid #2c3e50;
        }

        .ts-profile-nav .ts-account ul li a {
            color: #ecf0f1;
            padding: 10px;
            display: block;
            text-decoration: none;
        }

        .ts-profile-nav .ts-account ul li a:hover {
            background-color: red;
            color: #fff;
        }

        /* Dropdown Menu Visibility */
        .ts-profile-nav .ts-account:hover ul {
            display: block;
        }
        .b{
            padding: 10px;
        }
        
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Admin</h2>
        <ul>
            <li>Dashboard</li>
            <li>Member
                <ul>
                    <li>Add Members</li>
                    <li>Member Details</li>
                </ul>
            </li>
           <a href="" style="color: white; text-decoration: none;"></a> <li>Client</li></a>
           <li><a href="add_tourdata.php" style="color: white; text-decoration: none;">Tour</a></li>
           <a href="tourbooking.php" style="color: white; text-decoration: none;"><li>Tour Booking</li></a>
           <a href="" style="color: white; text-decoration: none;"> <li>Payment</li></a>
           <a href="" style="color: white; text-decoration: none;"> <li>Payment Receipt</li></a>
           <a href="" style="color: white; text-decoration: none;"> <li>Report</li></a>
        </ul>
    </div>
    <div class="brand">
        <p style="font-size: 20px; padding-top:1px; color:#fff">BloodBank & Donor Management System</p>

        <ul class="ts-profile-nav">
            <li class="ts-account">
                <a href="#"><i class="fas fa-user-circle b"></i>Account  <i class="fa fa-angle-down hidden-side b"></i></a>
                <ul>
                    <li><a href="profile.php">Profile</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </li>
        </ul>
    </div>
</body>
</html>