<?php
session_start();
include('config.php');
// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Escape user inputs for security
    $unm = $_POST['username'];
    $pwd = $_POST['password'];
    $sql = "SELECT * FROM `admin` WHERE `username`='$unm' AND `password`='$pwd'";
    $result = mysqli_query($conn, $sql);
    $data = mysqli_fetch_assoc($result);
    $count = mysqli_num_rows($result);

    if ($count > 0) {
        session_start();
        $_SESSION['admin_logged_in'] = $data['id'];
        $_SESSION['username'] = $data['username'];
        header("location:admin_dashboard.php");
    } else {
        echo "<script>alert('Check Your Username & Password!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Admin Login</title>
	<style>
		* {
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

.login-container {
    background-color: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 90%;
    max-width: 400px;
}

h1 {
    text-align: center;
    margin-bottom: 1.5rem;
}

.input-group {
    margin-bottom: 1rem;
}

label {
    display: block;
    margin-bottom: 0.5rem;
}

input {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    width: 100%;
    padding: 0.5rem;
    background-color: green;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background-color: lime;
}

@media (max-width: 500px) {
    .login-container {
        padding: 1rem;
    }

    h1 {
        font-size: 1.5rem;
    }

    input, button {
        font-size: 1rem;
    }
}

	</style>
    <script>function showAlert(message){
        alert(message);
    }</script>
</head>
<body>
    <div class="login-container">
        <h1>Admin Login</h1>
        <form action="#" method="POST">
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" name="submit">Login</button>
        </form>
    </div>
</body>
</html>
