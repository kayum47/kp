
<?php
include("config.php");
// Insert package
if (isset($_POST['insert'])) {
    $location = $_POST['location'];
    $days = $_POST['days'];
    $persons = $_POST['persons'];
    $rating = $_POST['rating'];
    $price = $_POST['price'];
    $image_url = $_POST['image_url'];

    $sql = "INSERT INTO packages (location, days, persons, rating, price, image_url) VALUES ('$location', '$days', '$persons', '$rating', '$price', '$image_url')";
    
    if ($conn->query($sql) === TRUE) {
        echo "New package created successfully";
        echo "<script>alert('New package created successfully');</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    header("Location: add_tourdata.php");
    exit();
}


// Update package
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $location = $_POST['location'];
    $days = $_POST['days'];
    $persons = $_POST['persons'];
    $rating = $_POST['rating'];
    $price = $_POST['price'];
    $image_url = $_POST['image_url'];

    $sql = "UPDATE packages SET location='$location', days='$days', persons='$persons', rating='$rating', price='$price', image_url='$image_url' WHERE id='$id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Package updated successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Delete package
if (isset($_POST['delete'])) {
    $id = $_POST['id'];

    $sql = "DELETE FROM packages WHERE id='$id'";
    
    if ($conn->query($sql) === TRUE) {
        echo "Package deleted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Fetch all packages for display
$sql = "SELECT * FROM packages";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="css/admin-style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .main-container {
            width: 90%;
            max-width: 1009px;
            margin: 25px 20px 0px 280px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        form input {
            padding: 10px;
            margin-right: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        form button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        form button:hover {
            background-color: #0056b3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #007bff;
            color: white;
        }

        td form {
            display: inline;
        }

        td form button {
            background-color: #f44336;
            padding: 5px 10px;
            border-radius: 3px;
        }

        td form button:hover {
            background-color: #d32f2f;
        }

        td form input[type="text"] {
            padding: 5px;
            margin: 0;
            width: auto;
        }
    </style>
</head>

<body>
<?php include('index.php'); ?>
    <div class="main-container">
        <h1>Admin Panel - Manage Tour Packages</h1>

        <form method="POST">
            <h2>Add New Package</h2>
            <input type="text" name="location" placeholder="Location" required>
            <input type="number" name="days" placeholder="Days" required>
            <input type="number" name="persons" placeholder="Persons" required>
            <input type="text" name="rating" placeholder="Rating" required>
            <input type="text" name="price" placeholder="Price" required>
            <input type="text" name="image_url" placeholder="Image URL" required>
            <button type="submit" name="insert">Insert</button>
        </form>

        <h2>All Packages</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Location</th>
                <th>Days</th>
                <th>Persons</th>
                <th>Rating</th>
                <th>Price</th>
                <th>Image URL</th>
                <th>Actions</th>
            </tr>

            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>" . $row["id"] . "</td>
                        <td>" . $row["location"] . "</td>
                        <td>" . $row["days"] . "</td>
                        <td>" . $row["persons"] . "</td>
                        <td>" . $row["rating"] . "</td>
                        <td>" . $row["price"] . "</td>
                        <td>" . $row["image_url"] . "</td>
                        <td>
                            <form method='POST' style='display:inline-block'>
                                <input type='hidden' name='id' value='" . $row["id"] . "'>
                                <button type='submit' name='delete'>Delete</button>
                            </form>
                            <form method='POST' style='display:inline-block'>
                                <input type='hidden' name='id' value='" . $row["id"] . "'>
                                <input type='text' name='location' value='" . $row["location"] . "' required>
                                <input type='number' name='days' value='" . $row["days"] . "' required>
                                <input type='number' name='persons' value='" . $row["persons"] . "' required>
                                <input type='text' name='rating' value='" . $row["rating"] . "' required>
                                <input type='text' name='price' value='" . $row["price"] . "' required>
                                <input type='text' name='image_url' value='" . $row["image_url"] . "' required>
                                <button type='submit' name='update'>Update</button>
                            </form>
                        </td>
                    </tr>";
                }
            } else {
                echo "0 results";
            }
            ?>

        </table>
    </div>
</body>

</html>

<?php
$conn->close();
?>
