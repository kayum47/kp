<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['bbdmsdid'] == 0)) {
    header('location:logout.php');
} else {

    if (isset($_POST['update'])) {
        $uid = $_SESSION['bbdmsdid'];
        $fnm = $_POST['fname'];
        $num = $_POST['number'];
        $email = $_POST['email'];
        $age = $_POST['age'];
        $gender = $_POST['gender'];
        $bg = $_POST['blood_group'];
        $dob = $_POST['date-of-birth'];
        $add = $_POST['address'];
        $state = $_POST['state'];
        $pass = $_POST['password'];
        $updt = "update blooddonars set `fname` ='$fnm',`number` ='$num',`email` ='$email',`age` ='$age',`gender` ='$gender',`blood_group` ='$bg',`date-of-birth` ='$dob',`address` ='$add',`state` ='$state',`password` ='$pass' where `id`='$uid'";
        $result = mysqli_query($con, $updt);
        echo '<script>alert("Profile has been updated")</script>';
        header("Location: profile.php");
    }
}

?>

<html>

<head>
    <title>BBDMS | User Profile</title>
    <style>
        body {
            background-color: #f4f4f4;
            align-items: center;
        }

        .container {
            margin-top: 75px;
            margin-bottom: 20px;
            display: flex;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;

            width: 100%;
        }

        .left {
            flex: 1;
        }

        .left img {
            width: 100%;
            height: 100%;

        }

        .right {
            flex: 1;
            padding: 20px;
        }

        .h2 {
            margin-bottom: 20px;
            color: #333;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"],
        input[type="tel"],
        input[type="email"],
        input[type="number"],
        input[type="date"],
        input[type="password"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        input[type="submit"] {
            width: 100%;
            background-color: #28a745;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <?php include("header.php") ?>
    <div class="container">
        <div class="left">
            <img src="images/blood-donor.jpg" alt="Image">
        </div>
        <div class="right">
            <h2 class="h2">Profile Details</h2>
            <form method="POST">
                <?php
                $uid = $_SESSION['bbdmsdid'];
                $sql = "SELECT * FROM `blooddonars` where id='$uid'";
                $result = mysqli_query($con, $sql);
                while ($data = mysqli_fetch_assoc($result)) {
                    $id = $data['id'];
                ?>
                    <label for="fullname">Full Name:</label>
                    <input type="text" id="fullname" name="fname" value="<?php echo $data['fname']; ?>" required>

                    <label for="mobile">Mobile Number:</label>
                    <input type="tel" id="mobile" name="number" value="<?php echo $data['number']; ?> " maxlength="10" required>

                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo $data['email']; ?>" required>

                    <label for="age">Age:</label>
                    <input type="number" id="age" name="age" value="<?php echo $data['age']; ?>" required>

                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender" required>
                        <option value="<?php echo $data['gender']; ?>"><?php echo $data['gender']; ?></option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>

                    <label for="bloodgroup">Blood Group:</label>
                    <select id="bloodgroup" name="blood_group" required>
                        <option value="<?php echo $data['blood_group']; ?>"><?php echo $data['blood_group']; ?></option>
                        <?php $sql = "SELECT * FROM `blood-group`";
                        $result = mysqli_query($con, $sql);
                        while ($data1 = mysqli_fetch_assoc($result)) {
                            $id = $data1['id'];
                        ?>
                            <option value="<?php echo $data1['bloodgroup']; ?>"><?php echo $data1['bloodgroup']; ?></option>
                        <?php }
                        ?>
                    </select>

                    <label for="dob">Date of Birth:</label>
                    <input type="date" id="dob" name="date-of-birth" value="<?php echo $data['date-of-birth']; ?>" required>

                    <label for="address">Address:</label>
                    <textarea id="address" name="address" rows="4" required><?php echo $data['address']; ?></textarea>

                    <label for="state">City:</label>
                    <input type="text" id="state" name="state" value="<?php echo $data['state']; ?>" required>

                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" value="<?php echo $data['password']; ?>" required>
                <?php
                }
                ?>
                <button type="submit" name="update">Update</button>

            </form>
        </div>
    </div>

    <?php include("footer.php") ?>
</body>

</html>