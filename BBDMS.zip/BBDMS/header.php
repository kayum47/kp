<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navigation Bar</title>
    <style>
        .nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #2c3e50; /* Dark Blue Background */
            position: fixed;
            top: 0;
            width: 97%;
            height: 70px;
            padding: 0 20px;
            z-index: 1000;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .nav h1 {
            font-size: 29px;
            color: #ffffff;
            margin: 0;
        }

        .nav h1 span {
            color: red; /* Orange accent for "BB" */
        }

        .nav a {
            color: #ffffff;
            padding: 20px 15px;
            text-decoration: none;
            font-size: 16px;
            transition: background-color 0.3s, color 0.3s;
        }

        .nav a:hover {
            background-color: red; /* Orange hover background */
            color: #ffffff;
            border-radius: 5px;
        }

        .nav-item.dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-menu {
            margin-top: 20px;
            display: none;
            position: absolute;
            background-color: #2c3e50; /* Dark Blue for dropdown */
            min-width: 120px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
        }

        .dropdown-menu a {
            color: #ffffff;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }

        .dropdown-menu a:hover {
            background-color: red; /* Orange hover for dropdown items */
        }

        .nav-item.dropdown:hover .dropdown-menu {
            display: block;
        }

        .nav .dropdown-divider {
            height: 1px;
            background-color: #444;
            margin: 5px 0;
        }


    </style>
</head>
<body>
    <div class="nav">
        <h1><span>BB</span>DMS</h1>
        <div>
            <a href="index.php">Home</a>
            <a href="AboutUs.php">About Us</a>
            <a href="ContactUs.php">Contact Us</a>
            <a href="DonorList.php">Donor List</a>
            <a href="SearchDonor.php">Search Donor</a>

            <?php if (isset($_SESSION['bbdmsdid']) && strlen($_SESSION['bbdmsdid']) != 0) { ?>
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button">
                        My Account
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="profile.php">Profile</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="request-received.php">Requests</a>
                        <a class="dropdown-item" href="logout.php">Logout</a>
                    </div>
                </div>
            <?php } else { ?>
                <a href="Admin/index.php">Admin</a>
                <a href="user-login.php">Login</a>
            <?php } ?>
        </div>
    </div>
</body>
</html>
