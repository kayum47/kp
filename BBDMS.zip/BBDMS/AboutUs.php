<?php
session_start();
include('includes/dbconnection.php');
?>
<html>
<head>
    <title>BBDMS | About Us</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem 1rem;
        }

        .h2 {
            margin-bottom: 1rem;
            font-size: 2.5rem;
            color: #ff4d4d;
            text-align: center;
        }

        .content {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 2rem;
            background: #fff;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .text {
            flex: 1;
        }

        .text h3 {
            margin-top: 1.5rem;
            font-size: 1.8rem;
            color: #333;
        }

        .text p {
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
            color: #666;
        }

        .image {
            flex: 1;
        }

        .image img {
            width: 100%;
            border-radius: 10px;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .content {
                flex-direction: column;
            }

            .image {
                order: -1;
            }
        }
    </style>
</head>
<body>
    <?php include("header.php") ?>
    <div class="container">
        <h2 class="h2">About Us</h2>
        <div class="content">
            <div class="text">
                <p>Welcome to our Blood Bank & Management System. We are dedicated to providing a reliable and efficient platform for managing blood donations and ensuring a safe supply of blood to those in need.</p>
                <p>Our mission is to connect donors with recipients seamlessly, promote voluntary blood donation, and manage the distribution of blood efficiently. We strive to save lives by maintaining a well-organized and transparent system.</p>
                <h3>Our Vision</h3>
                <p>To create a world where every patient in need of blood can easily access safe and sufficient blood supply.</p>
                <h3>Our Mission</h3>
                <p>To provide a reliable and efficient platform for managing blood donations, ensuring a safe and sufficient supply of blood, and promoting voluntary blood donation.</p>
            </div>
            <div class="image">
                <img src="images/blood-donation-1.jpg" alt="Blood Donation">
            </div>
        </div>
    </div>
    <?php include("footer.php") ?>
</body>

</html>