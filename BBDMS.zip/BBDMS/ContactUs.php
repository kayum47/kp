<?php
session_start();
include('includes/dbconnection.php');
if (isset($_REQUEST['submit'])) {
    $nm = $_REQUEST['name'];
    $num = $_REQUEST['number'];
    $email = $_REQUEST['email'];
    $msg = $_REQUEST['message'];
    $sql = "INSERT INTO contactus (name, number, email, message) VALUES ('$nm', '$num', '$email', '$msg')";
    $query = mysqli_query($con, $sql);
    if ($query) {
        $_SESSION['msg'] = "Blood Group Created successfully";
    } else {
        $_SESSION['error'] = "Something went wrong. Please try again";
    }
    header("Location: ContactUs.php");
    exit();
}
?>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | ContactUs</title>
    <style>
        body {
            background-color: #f4f4f4;
            align-items: center;
        }

        .container {
            margin-top: 75px;
            margin-bottom: 20px;
            display: flex;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;

            width: 100%;
        }

        .left {
            flex: 1;
        }

        .left img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .right {
            flex: 1;
            padding: 20px;
        }

        .h2 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input,
        textarea {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        button {
            padding: 10px;
            background-color: #007BFF;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .errorWrap {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }

        .succWrap {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
    </style>
</head>

<body>
    <?php include("header.php") ?>
    <div class="container">
        <div class="left">
            <img src="images/1.jpg" alt="Image">
        </div>
        <div class="right">
            <h2 class="h2">Contact Us</h2>
            <form id="contactForm" method="post">
                <?php
                if (isset($_SESSION['error'])) { ?>
                    <div class="errorWrap"><strong>ERROR</strong>: <?php echo htmlentities($_SESSION['error']); ?></div>
                <?php unset($_SESSION['error']); // Clear the message after displaying it
                } else if (isset($_SESSION['msg'])) { ?>
                    <div class="succWrap"><strong>SUCCESS</strong>: <?php echo htmlentities($_SESSION['msg']); ?></div>
                <?php unset($_SESSION['msg']); // Clear the message after displaying it
                } ?>
                <input type="text" id="name" name="name" placeholder="Please enter your name." required>
                <input type="tel" id="number" name="number" placeholder="Please enter your phone number." required>
                <input type="email" id="email" name="email" placeholder="Please enter your email address." required>
                <textarea id="message" name="message" placeholder="Please enter your message" required></textarea>
                <button type="submit" name="submit">Send Message</button>
            </form>
        </div>
    </div>
    <?php include("footer.php") ?>
</body>

</html>