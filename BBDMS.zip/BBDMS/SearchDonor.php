<?php
session_start();
include('includes/dbconnection.php');
?>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Search Donor List</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .container1 {
            background-color: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            width: 95%;
            margin-top: 40px;
        }

        .h1 {
            color: #2c3e50;
            font-size: 26px;
            text-align: center;
            margin-bottom: 20px;
            font-weight: 600;
            border-bottom: 1px solid #2c3e50;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 500;
            margin-bottom: 8px;
            font-size: 16px;
            color: #555;
        }

        .required {
            color: red;
            margin-left: 4px;
        }

        select,
        textarea {
            width: 100%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        select:focus,
        textarea:focus {
            border-color: #4d90fe;
            box-shadow: 0 0 5px rgba(81, 203, 238, 0.8);
            outline: none;
        }

        textarea {
            resize: none;
            height: 50px;
        }

        .p {
            font-size: 25px;
            color: red;
            margin-top: 20px;
            text-align: center;
            border: 1px solid red;
            border-radius: 4px;
        }

        .button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        .button:hover {
            background-color: #0056b3;
        }

        .container {
            max-width: 1250px;
            margin: 0 auto;
            padding: 20px;
            background-color: whitesmoke;
            border-radius: 5px;
        }

        .title {
            text-align: center;
            font-size: 2.5em;
            font-weight: bold;
            margin-top: 70px;
            padding-bottom: 10px;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
        }

        .grid-container {
            margin-top: 40px;
            display: grid;
            grid-template-columns: repeat(3, minmax(300px, 1fr));
            gap: 10px;
            padding: 20px 0;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
        }

        .profile {
            text-align: center;
            margin-bottom: 15px;
        }

        .avatar {
            width: 100%;
            max-width: 250px;
            height: auto;
            border-radius: 5%;
            margin: 0 auto 30px;
        }

        .name {
            font-size: 24px;
            font-weight: bold;
            color: #2980b9;
        }

        .details table {
            width: 100%;
            border-spacing: 1;
            font-size: 16px;
        }

        .details td {
            padding: 8px 0;
        }

        .reveal-button {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .reveal-button:hover {
            background-color: #1f6397;
        }

        /* Media Queries for smaller screens */
        @media (max-width: 600px) {
            .title {
                font-size: 2em;
            }

            .grid-container {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }

            .name {
                font-size: 20px;
            }
        }
    </style>
    <script>
        function revealContact(contactNumber) {
            alert("Contact Number: " + contactNumber);
        }
    </script>
</head>

<body>
    <?php include("header.php") ?>
    <div class="container1">
        <h1 class="h1">Search Blood Donor</h1>
        <form method="POST">
            <div class="form-group">
                <label for="blood-group">Blood Group<span class="required">*</span></label>
                <select id="bloodgroup" name="blood_group" required>
                    <option value="">Select Blood Group</option>
                    <?php
                    $sql = "SELECT * FROM `blood-group`";
                    $result = mysqli_query($con, $sql);
                    while ($data = mysqli_fetch_assoc($result)) {
                    ?>
                        <option value="<?php echo $data['bloodgroup']; ?>"><?php echo $data['bloodgroup']; ?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="button" name="sub">Submit</button>
        </form>
    </div>
    <?php
    if (isset($_POST['sub'])) {
        $bloodgroup = $_POST['blood_group'];
        $sql = "SELECT * FROM blooddonars WHERE blood_group = '$bloodgroup'";
        $result = mysqli_query($con, $sql);
        if (mysqli_num_rows($result) > 0) {
    ?>
            <div>
                <div class="container">
                    <h1 class="title">Blood Donor List</h1>
                    <div class="grid-container">
                        <?php
                        while ($data = mysqli_fetch_assoc($result)) {
                            $id = $data['id'];
                        ?>
                            <div class="card">
                                <div class="profile">
                                    <img src="images/blood-donor.jpg" alt="Blood Donor" class="avatar" />
                                    <div class="name"><?php echo $data['fname']; ?></div>
                                </div>
                                <div class="details">
                                    <table>
                                        <tr>
                                            <td>Gender</td>
                                            <td><?php echo $data['gender']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Blood Group</td>
                                            <td><?php echo $data['blood_group']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Date-of-birth</td>
                                            <td><?php echo $data['date-of-birth']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Email ID</td>
                                            <td><?php echo $data['email']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>Age</td>
                                            <td><?php echo $data['age']; ?></td>
                                        </tr>
                                        <tr>
                                            <td>City</td>
                                            <td><?php echo $data['state']; ?></td>
                                        </tr>
                                    </table>
                                </div>
                                <!-- Button to show contact number in an alert -->
                                <button class="reveal-button" onclick="revealContact('<?php echo $data['number']; ?>')">Show Contact Number</button>
                            </div>
                        <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
    <?php
        } else {
            echo "<p class='p'>No Record Found</p>";
        }
    } ?>
    <?php include("footer.php") ?>
</body>

</html>