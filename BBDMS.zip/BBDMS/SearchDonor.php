<?php
session_start();
include('includes/dbconnection.php');
?>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Search Donor List</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        .container1 {
            background-color: #fff;
            padding: 20px 30px;
            border-radius: 8px;
            width: 95%;
            margin-top: 40px;
        }

        .h1 {
            color: #333;
            font-size: 26px;
            text-align: center;
            margin-bottom: 20px;
            font-weight: 600;
            border-bottom: 1px solid black;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: 500;
            margin-bottom: 8px;
            font-size: 16px;
            color: #555;
        }

        .required {
            color: red;
            margin-left: 4px;
        }

        select,
        textarea {
            width: 100%;
            padding: 8px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        select:focus,
        textarea:focus {
            border-color: #4d90fe;
            box-shadow: 0 0 5px rgba(81, 203, 238, 0.8);
            outline: none;
        }

        textarea {
            resize: none;
            height: 50px;
        }

        .p {
            font-size: 25px;
            color: red;
            margin-top: 20px;
            text-align: center;
            border: 1px solid red;
            border-radius: 4px;
        }

        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        button:hover {
            background-color: #0056b3;
        }

        .title {
            text-align: center;
            font-size: 2em;
            border-bottom: 2px solid black;
            margin: 80px auto 0;
        }

        .container {
            margin-top: 40px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            justify-content: space-between;
            padding: 20px;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            padding: 20px;
            margin-right: 10px;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
        }

        .profile {
            text-align: center;
            margin-bottom: 15px;
        }

        .avatar {
            width: 380px;
            height: 300px;
            border-radius: 5%;
            margin: 0 auto 30px;
        }

        .name {
            font-size: 30px;
            font-weight: bold;
        }

        .details table {
            width: 100%;
            border-spacing: 1;
            font-size: 16px;
        }

        .details td {
            padding: 8px 0;

        }
    </style>
</head>

<body>
    <?php include("header.php") ?>
    <div class="container1">
        <h1 class="h1">Search Blood Donor</h1>
        <form method="POST">
            <div class="form-group">
                <label for="blood-group">Blood Group<span class="required">*</span></label>
                <select id="bloodgroup" name="blood_group" required>
                    <option value="">Select Blood Group</option>
                    <?php
                    $sql = "SELECT * FROM `blood-group`";
                    $result = mysqli_query($con, $sql);
                    while ($data = mysqli_fetch_assoc($result)) {
                    ?>
                        <option value="<?php echo $data['bloodgroup']; ?>"><?php echo $data['bloodgroup']; ?></option>
                    <?php
                    }
                    ?>
                </select>
            </div>
            <button type="submit" name="sub">Submit</button>
        </form>
    </div>
    <?php
    if (isset($_POST['sub'])) {
        $bloodgroup = $_POST['blood_group'];
        $sql = "SELECT * FROM blooddonars WHERE blood_group = '$bloodgroup'";
        $result = mysqli_query($con, $sql);
        if (mysqli_num_rows($result) > 0) {
    ?>
            <div>
                <h1 class="title">Blood Donor List</h1>
                <div class="container">
                    <?php
                    while ($data = mysqli_fetch_assoc($result)) {
                    ?>
                        <div class="card">
                            <div class="profile">
                                <img src="images/blood-donor.jpg" alt="Blood Donor" style="border:1px #000 solid" class="avatar" />
                                <div class="name"><?php echo $data['fname']; ?></div>
                            </div>
                            <div class="details">
                                <table>
                                    <tr>
                                        <td>Gender</td>
                                        <td><?php echo $data['gender']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Blood Group</td>
                                        <td><?php echo $data['blood_group']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Date-of-birth</td>
                                        <td><?php echo $data['date-of-birth']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Email ID</td>
                                        <td><?php echo $data['email']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Age</td>
                                        <td><?php echo $data['age']; ?></td>
                                    </tr>
                                    <tr>
                                        <td>State</td>
                                        <td><?php echo $data['state']; ?></td>
                                    </tr>
                                </table>
                            </div>
                            <br>
                        </div>
                    <?php
                    }
                    ?>
                </div>
            </div>
    <?php
        } else {
            echo "<p class='p'>No Record Found</p>";
        }
    } ?>
    <?php include("footer.php") ?>
</body>

</html>