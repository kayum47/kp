<?php
include('includes/dbconnection.php');
if (isset($_POST['submit'])) {
    $cid=$_GET['cid'];
    $nm = $_POST['name'];
    $email = $_POST['email'];
    $num = $_POST['number'];
    $brf = $_POST['bloodrequirefor'];
    $msg = $_POST['message'];

    $sql = "INSERT INTO bloodrequirer (BloodDonarid,name, email,number, bloodrequirefor, message) VALUES ('$cid','$nm', '$email', '$num', '$brf', '$msg')";
    $query = mysqli_query($con, $sql);
    if ($query) {
        echo "<script>alert('Request send successful!');</script>";
        echo "<script>window.location.href='index.php'</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Blood Request</title>
    <style>
    
        body {
            background-color: #f4f4f4;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .main-container1 {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            background-color: white;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 95%;
            height: auto;
            margin: 80px 0px 10px 40px;
        }

        .title {
            text-align: center;
            padding: 20px 0;
            font-size: 2rem;
            font-weight: bold;
            color: #333;
            text-transform: uppercase;
            letter-spacing: 2px;
            border-bottom: 1px solid #ccc;
            margin-bottom: 20px;
        }

        .image-container {
            width: 50%;
            overflow: hidden;
        }

        .image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .form-container {
            padding: 20px;
            width: 50%;
        }

        h2 {
            margin-bottom: 20px;
            text-align: center;
            font-size: 1.8rem;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;

        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: 1rem;
            color: #555;
        }

        input,
        select,
        textarea {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 1rem;
        }

        textarea {
            resize: none;
            height: 80px;
        }

        .btn {
            display: inline-block;
            width: 100%;
            background-color: #007BFF;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

        .form-wrapper {
            display: flex;
            width: 100%;
        }
    </style>
</head>

<body>
    <?php include("header.php") ?>
    <div class="main-container1">

        <div class="title">Contact For Blood</div>

        <div class="form-wrapper">
            <div class="image-container">
                <img src="images/blog3.jpg" alt="Blood Donation Image">
            </div>
            <div class="form-container">
                <h2>Fill the following form for blood</h2>
                <form id="bloodForm" method="post">
                    <div class="form-group">
                        <label for="name">Your Name</label>
                        <input type="text" id="name" name="name" placeholder="Please enter your name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" placeholder="Please enter your email address" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="tel" id="phone" name="number" placeholder="Please enter your phone number" required>
                    </div>
                    <div class="form-group">
                        <label for="blood-require">Blood Required For</label>
                        <select id="blood-require" name="bloodrequirefor" required>
                            <option value="">Select an option</option>
                            <option value="Personal">Personal</option>
                            <option value="Family">Family</option>
                            <option value="Friend">Friend</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" placeholder="Please enter your message"></textarea>
                    </div>
                    <button type="submit" class="btn" name="submit">Send Message</button>
                </form>
            </div>
        </div>
    </div>
    <?php include("footer.php") ?>
</body>

</html>