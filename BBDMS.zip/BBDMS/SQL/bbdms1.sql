-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2024 at 11:00 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdms1`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `AdminName` varchar(50) NOT NULL,
  `UserName` varchar(50) NOT NULL,
  `MobileNumber` varchar(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `AdminName`, `UserName`, `MobileNumber`, `Email`, `Password`) VALUES
(1, 'Admin', 'admin', '9632587410', 'admin123@gmail.com', 'admin47'),
(3, 'kp', 'kp', '9898678042', 'kp@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `blood-group`
--

CREATE TABLE `blood-group` (
  `id` int(11) NOT NULL,
  `bloodgroup` varchar(50) DEFAULT NULL,
  `creation_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blood-group`
--

INSERT INTO `blood-group` (`id`, `bloodgroup`, `creation_date`) VALUES
(1, 'A+', '2024-09-05 09:10:25'),
(2, 'A-', '2024-09-05 09:10:25'),
(3, 'AB+', '2024-09-05 09:10:25'),
(4, 'AB-', '2024-09-05 09:10:25'),
(5, 'B+', '2024-09-05 09:10:25'),
(6, 'B-', '2024-09-05 09:10:25'),
(7, 'O+', '2024-09-05 09:10:25'),
(8, 'O-', '2024-09-05 09:10:25');

-- --------------------------------------------------------

--
-- Table structure for table `blooddonars`
--

CREATE TABLE `blooddonars` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `number` varchar(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `blood_group` varchar(10) DEFAULT NULL,
  `date-of-birth` date DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `date-time` datetime(6) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `blooddonars`
--

INSERT INTO `blooddonars` (`id`, `fname`, `number`, `email`, `age`, `gender`, `blood_group`, `date-of-birth`, `address`, `date-time`, `state`, `password`) VALUES
(1, 'kayum kayum', '963258741', 'kp@gmail.com', 630, 'male', 'AB+', '2005-05-10', 'dfkjfdlski', '2024-08-12 14:12:00.000000', 'dkfjbdib', '4747'),
(5, 'kayum parmar', '2147483647', 'kayumparmar10@gmail.com', 19, 'male', 'A+', '2005-05-10', 'hello kayum ', '2024-08-12 14:18:00.000000', 'rajkot', '123456'),
(6, 'dhamo1', '2147483647', 'dhamo@gmail.com', 25, 'male', 'O+', '2550-01-05', 'dfliuifuiugfoiduh', '2024-08-12 14:20:00.000000', 'upleta', '215'),
(9, 'kp', '2147483647', 'kp@gmail.com', 36, 'male', 'B+', '2000-05-15', 'fouughdi uriuriugir uth irthr h', '2024-08-16 14:33:00.000000', 'Rajot', 'kp123'),
(12, 'sagar solanki', '2147483647', 'ss123@gmail.com', 20, 'male', 'B+', '2000-02-20', 'hello ss', '2024-09-12 10:19:00.000000', 'rajkot', '123'),
(13, 'hello', '987654321', 'hello@gmail.com', 20, 'male', 'O-', '1987-02-05', 'hello', '2024-09-13 15:42:00.000000', 'upleta', 'hello'),
(14, 'parmar kayum hanifbhai', '963258741', 'kp@gmail.com', 20, 'male', 'B-', '2005-05-10', 'rajkot', '2024-09-18 10:32:00.000000', 'upleta', 'kp'),
(15, 'Kayum Parmar', '9898678042', 'kp@gmail.com', 19, 'male', 'AB+', '2005-02-10', 'kalana', '2024-09-22 08:12:00.000000', 'Rajkot', '7'),
(16, 'sdsjbd', '9896641613', 'dhamo@gmail.com', 10, 'female', 'AB+', '2000-02-10', 'dfsdf', '2024-09-22 08:18:00.000000', 'upleta', '123');

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

CREATE TABLE `contactus` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL,
  `Posting_Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactus`
--

INSERT INTO `contactus` (`id`, `name`, `number`, `email`, `message`, `Posting_Date`) VALUES
(1, 'kayum', '2147483647', 'kp@gmail.com', 'dkjjgjhkd uhh ', '2024-09-06 15:08:33'),
(4, 'kayum parmar', '2147483647', 'kayumparmar10@gmail.com', 'hello i am kayum parmar\r\n', '2024-09-06 15:08:33'),
(15, 'sagar solanki', '2147483647', 'ss123@gmail.com', 'hi i am sagar', '2024-09-12 10:23:27'),
(18, 'parmar kayum hanif bhai', '2147483647', 'kp@gmail.com', 'hello i am hero', '2024-09-18 10:23:10'),
(19, 'kayum parmar', '2147483647', 'kp@gmail.com', '123', '2024-09-22 07:50:08'),
(20, 'kk', '963258741', 'kp@gmail.com', 'bb', '2024-09-22 07:53:54'),
(21, 'mm', '2147483647', 'kp@gmail.com', 'mm', '2024-09-22 07:56:54'),
(22, 'kk', '9632145870', 'amitk@gmail.com', 'ff', '2024-09-22 08:00:59');

-- --------------------------------------------------------

--
-- Table structure for table `contactusinfo`
--

CREATE TABLE `contactusinfo` (
  `id` int(11) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Number` varchar(10) NOT NULL,
  `Email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contactusinfo`
--

INSERT INTO `contactusinfo` (`id`, `Address`, `Number`, `Email`) VALUES
(1, 'Test Demo test demo kayum parmar', '9898678042', 'kayumparmar786k@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blood-group`
--
ALTER TABLE `blood-group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blooddonars`
--
ALTER TABLE `blooddonars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactus`
--
ALTER TABLE `contactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contactusinfo`
--
ALTER TABLE `contactusinfo`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `blood-group`
--
ALTER TABLE `blood-group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `blooddonars`
--
ALTER TABLE `blooddonars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `contactus`
--
ALTER TABLE `contactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `contactusinfo`
--
ALTER TABLE `contactusinfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
