<?php
include('includes/dbconnection.php');
if (isset($_POST['submit'])) {
    $fnm = $_POST['fname'];
    $num = $_POST['number'];
    $email = $_POST['email'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $bg = $_POST['blood_group'];
    $dob = $_POST['date-of-birth'];
    $add = $_POST['address'];
    $dt = $_POST['date-time'];
    $state = $_POST['state'];
    $pass = $_POST['password'];

    $sql = "INSERT INTO blooddonars (fname, number, email, age, gender, blood_group, `date-of-birth`, address, `date-time`, state, password) VALUES ('$fnm', '$num', '$email', '$age', '$gender', '$bg', '$dob', '$add', '$dt', '$state', '$pass')";
    $query = mysqli_query($con, $sql);
    if ($query) {
        echo "<script>alert('Registration successful!');</script>";
        echo "<script>window.location.href='index.php'</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Registration Page</title>
    <style>
        /* Body styling */
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #e0eafc, #cfdef3);
            color: #333;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            
        }

        .container {
            background-color: #ffffff;
            padding: 3rem 2rem;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            width: 40%;
            text-align: center;
        }

        h2 {
            font-size: 1.8rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 2rem;
        }

        label {
            display: block;
            text-align: left;
            margin-top: 1.2rem;
            font-weight: bold;
            color: #34495e;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="password"],
        input[type="datetime-local"],
        input[type="date"],
        textarea,
        select {
            width: 100%;
            padding: 0.7rem;
            margin-top: 0.5rem;
            border: none;
            border-radius: 8px;
            background-color: #f3f3f3;
            box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.05);
            font-size: 1rem;
            outline: none;
            transition: box-shadow 0.2s ease-in-out;
        }

        input:focus,
        select:focus,
        textarea:focus {
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.5);
        }

        button {
            display: block;
            width: 100%;
            padding: 0.8rem;
            margin-top: 2rem;
            background-color: #2980b9;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #1c5981;
        }

        .back-button {
            background-color: #95a5a6;
            margin-top: 1rem;
        }

        .back-button:hover {
            background-color: #7f8c8d;
        }

        /* Error message styling */
        .error-message {
            color: red;
            margin-top: 1rem;
            text-align: center;
        }

        /* Media queries for responsiveness */
        @media (max-width: 600px) {
            .container {
                padding: 2rem 1.5rem;
            }

            h2 {
                font-size: 1.6rem;
            }
        }

        @media (max-width: 400px) {
            .container {
                padding: 1.5rem 1rem;
            }

            h2 {
                font-size: 1.4rem;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Register Now</h2>
        <form id="registration-form" method="post">
            <label for="full-name">Full Name</label>
            <input type="text" id="full-name" name="fname" required>

            <label for="number">Phone Number</label>
            <input type="text" id="number" name="number" maxlength="10" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="age">Age</label>
            <input type="number" id="age" name="age" min="0" required>

            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
                <option value="">Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
            </select>

            <label for="bloodgroup">Blood Group</label>
            <select id="bloodgroup" name="blood_group" required>
                <option value="">Select Blood Group</option>
                <?php $sql = "SELECT * FROM `blood-group`";
                $result = mysqli_query($con, $sql);
                while ($data = mysqli_fetch_assoc($result)) { ?>
                    <option value="<?php echo $data['bloodgroup']; ?>"><?php echo $data['bloodgroup']; ?></option>
                <?php } ?>
            </select>

            <label for="dob">Date of Birth</label>
            <input type="date" id="dob" name="date-of-birth" required>

            <label for="address">Address</label>
            <textarea id="address" name="address" rows="3" required></textarea>

            <label for="registration-datetime">Registration Date-Time</label>
            <input type="datetime-local" id="registration-datetime" name="date-time" required readonly>

            <label for="state">City</label>
            <input type="text" id="state" name="state" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" name="submit">Register</button>
            <button type="button" class="back-button" onclick="goHome()">Back to Home</button>

            <p id="error-message" class="error-message"></p>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', (event) => {
            // Set current date-time for registration field
            var now = new Date();
            var formattedDateTime = now.toISOString().slice(0, 16);
            document.getElementById('registration-datetime').value = formattedDateTime;

            // Prevent future dates in the Date of Birth field
            var today = new Date().toISOString().split('T')[0];
            document.getElementById('dob').setAttribute('max', today);
        });

        // Prevent negative age values
        document.getElementById('age').addEventListener('input', function() {
            if (this.value < 0) {
                this.value = 0;
            }
        });

        function goHome() {
            window.location.href = 'index.php';
        }
    </script>
</body>

</html>
