<?php
include('includes/dbconnection.php');
$sql = "SELECT * FROM `contactusinfo`";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <title>Footer</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    }

    .footer-container {
      background-color: #2c3e50;
      /* Dark blue background */
      color: white;
      padding: 30px 20px;
      text-align: center;
    }

    .footer-section {
      width: 30%;
      display: inline-block;
      vertical-align: top;
      color: white;
      padding: 20px;
      /* Added padding for spacing */
      text-align: left;
      margin-bottom: 20px;
      box-sizing: border-box;
    }

    .footer-section h1,
    .footer-section h2 {
      color: red;
      /* Red color for headings */
      margin-bottom: 15px;
    }

    .footer-section p {
      font-size: 15px;
      margin: 0 0 10px 0;
    }

    .footer-section ul {
      list-style-type: disc;
      padding: 0;
      margin: 0;
    }

    .footer-section ul li {
      margin: 8px 0;
      font-size: 15px;
    }

    .footer-section ul li i {
      margin-right: 10px;
      color: red;
      /* Red color for icons */
    }

    .footer-section ul a {
      color: white;
      text-decoration: none;
      font-size: 15px;
      transition: color 0.3s;
    }

    .footer-section ul a:hover {
      color: red;
      /* Red hover color for links */
    }

    .footer {
      background-color: #2c3e50;
      /* Dark blue background */
      color: white;
      text-align: center;
      padding: 15px;
      margin-top: 2px;
    }

    .address-section {
      margin-left: 120px;
      /* Reset margin on smaller screens */
    }

    /* Responsive Design */
    @media screen and (max-width: 768px) {
      .footer-section {
        width: 100%;
        display: block;
        text-align: center;
        margin-bottom: 20px;
        padding: 10px;
        /* Adjusted padding for smaller screens */
      }

      .footer-section ul {
        text-align: center;
      }
    }
  </style>
</head>

<body>
  <div class="footer-container">
    <div class="footer-section">
      <h1><span style="color: red;">Blood Bank &</span> Donor Management System</h1>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
    <div class="footer-section address-section">
      <h2>Address</h2>
      <ul>
        <?php while ($data = mysqli_fetch_assoc($result)) {
          $id = $data['id']; ?>
          <li><i class="fas fa-map-marker-alt"></i><?php echo $data['Address']; ?></li>
          <li><i class="fas fa-phone-alt"></i><?php echo $data['Number']; ?></li>
          <li><i class="fas fa-envelope"></i><?php echo $data['Email']; ?></li>
        <?php }
        ?>
      </ul>
    </div>
    <div class="footer-section">
      <h2>Quick Links</h2>
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="ContactUs.php">Contact Us</a></li>
      </ul>
    </div>
  </div>
  <div class="footer">
    &copy; Blood Bank Donor Management System
  </div>
</body>

</html>