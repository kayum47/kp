<?php
session_start();
$uid = $_SESSION['bbdmsdid']; // Assuming this is properly set in your session

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Blood Requirer Details</title>
    <style>
        body {
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
        }

        .container {
            font-family: Arial, sans-serif;
            width: 90%;
            margin: 80px 0px 10px 40px;
            text-align: center;
            background-color: #fff;
            padding: 30px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        .hh1 {
            font-size: 2rem;
            margin-bottom: 10px;
            color: #333;
        }

        .icon {
            font-size: 3rem;
            color: red;
            margin-bottom: 10px;
        }

        .hh2 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
            font-weight: bold;
        }

        td {
            color: #333;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>

<body>
    <?php include("header.php") ?>
    <div class="container">
        <h1 class="hh1">Request Received</h1>
        <div class="icon">-👥-</div>
        <h2 class="hh2">Below is the detail of Blood Requirer.</h2>

        <table>
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                    <th>Blood Require For</th>
                    <th>Message</th>
                    <th>Apply Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                    include('includes/dbconnection.php');

                    // Use ? as a placeholder and prepare the query
                    $sql = "SELECT 
                                bloodrequirer.BloodDonarid,
                                bloodrequirer.name AS requirer_name,
                                bloodrequirer.email AS requirer_email,
                                bloodrequirer.number AS requirer_number,
                                bloodrequirer.bloodrequirefor,
                                bloodrequirer.message,
                                bloodrequirer.ApplyDate
                            FROM 
                                bloodrequirer 
                            JOIN 
                                blooddonars 
                            ON 
                                blooddonars.id = bloodrequirer.BloodDonarid 
                            WHERE 
                                bloodrequirer.BloodDonarid = '$uid'";
                    // // Prepare the statement
                    // $stmt = mysqli_prepare($con, $sql);

                    // // Bind the parameter (i.e., uid) to the placeholder
                    // mysqli_stmt_bind_param($stmt, "i", $uid);

                    // // Execute the prepared statement
                    // mysqli_stmt_execute($stmt);

                    // // Get the result set from the prepared statement
                    // $result = mysqli_stmt_get_result($stmt);
                    $query = mysqli_query($con, $sql);
                    // Check if rows were returned
                    if (mysqli_num_rows($query) > 0) {
                        $cnt = 1;
                        while ($data = mysqli_fetch_assoc($query)) {
                    ?>
                            <td><?php echo ($cnt); ?></td>
                            <td><?php echo $data['requirer_name']; ?></td>
                            <td><?php echo $data['requirer_number']; ?></td>
                            <td><?php echo $data['requirer_email']; ?></td>
                            <td><?php echo $data['bloodrequirefor']; ?></td>
                            <td><?php echo $data['message']; ?></td>
                            <td><?php echo $data['ApplyDate']; ?></td>
                </tr>
            <?php
                            $cnt++;
                        }
                    } else {
            ?>
            <tr>
                <th colspan="7" style="color:red; text-align :center; "> No Record found</th>
            </tr>
        <?php
                    }
                    // Close the statement
                    // mysqli_stmt_close($stmt);
        ?>
            </tbody>
        </table>
    </div>
    <?php include("footer.php") ?>
</body>

</html>