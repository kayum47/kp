<?php
session_start();
include('includes/dbconnection.php');
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank & Donor Management System</title>
    <style>
        .carousel {
            position: relative;
            max-width: 100%;
            overflow: hidden;
            border: 1px solid #ddd;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin: 70px auto 0;
            /* Adjusted margin to avoid overlap with navbar */
        }

        .slides {
            display: flex;
            transition: transform 0.5s ease-in-out;
        }

        .slide {
            min-width: 100%;
            box-sizing: border-box;
        }

        .slide img {
            width: 100%;
            display: block;
        }

        .prev,
        .next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            z-index: 10;
        }

        .prev {
            left: 10px;
        }

        .next {
            right: 10px;
        }

        /* BLOOD GROUPS */
        .container {
            width: 95%;
            margin: 0 auto;
            padding: 30px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-top: 10px;
        }

        .container1 {
            display: inline-flex;
        }

        .title {
            text-align: center;
            font-size: 2em;
            margin-top: 0;
            border-bottom: 2px solid black;
        }

        .subtitle {
            text-align: center;
            color: #777;
        }

        .blood-groups {
            list-style: inside;
            padding: 0;
            text-align: left;
        }

        .blood-groups li {
            margin: 15px 0;
        }

        .blood-groupdiv {
            width: 50%;
        }

        .universal-title {
            text-align: center;
            font-size: 1.5em;
            margin-top: 40px;
        }

        .universal-description {
            text-align: center;
            color: #555;
            margin-bottom: 40px;
        }

        .donate-button {
            display: block;
            width: 200px;
            margin: 0 auto;
            padding: 10px;
            background-color: #ff4d4d;
            color: #fff;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }

        .donate-button:hover {
            background-color: #e60000;
        }

        .a {
            color: white;
            padding: 20px 20px;
            text-decoration: none;
            font-size: 17px;
            border-radius: 5px;
        }

        /*poster*/
        .poster-container {
            margin-top: 5px;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: space-between;
            text-align: left;
            background-color: white;
            padding: 30px;
            border: 2px solid #e1e1e1;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            width: 95%;
            margin-bottom: 10px;
        }

        .poster-image {
            max-width: 400px;
            height: auto;
            margin-left: 50px;
            padding-right: 80px;
        }

        .poster-content {
            max-width: 500px;
            padding-left: 90px;
        }

        h1 {
            color: #d32f2f;
            font-size: 28px;
            margin-bottom: 15px;
        }

        .p {
            color: #333;
            font-size: 19px;
            line-height: 1.6;
        }
    </style>
    <script>
        let currentIndex = 0;

        function showSlide(index) {
            const slides = document.querySelector('.slides');
            const totalSlides = slides.children.length;

            if (index >= totalSlides) {
                currentIndex = 0;
            } else if (index < 0) {
                currentIndex = totalSlides - 1;
            } else {
                currentIndex = index;
            }

            const offset = -currentIndex * 100;
            slides.style.transform = `translateX(${offset}%)`;
        }

        function moveSlide(step) {
            showSlide(currentIndex + step);
        }

        // Auto slide every 3 seconds
        setInterval(() => {
            moveSlide(1);
        }, 3000);
    </script>
</head>

<body>
    <?php include("header.php") ?>
    <div class="carousel">
        <div class="slides">
            <div class="slide"><img src="images/banner1.jpg" alt="Image 1"></div>
            <div class="slide"><img src="images/banner2.jpg" alt="Image 2"></div>
            <div class="slide"><img src="images/banner3.jpg" alt="Image 3"></div>
        </div>
        <button class="prev" onclick="moveSlide(-1)">&#10094;</button>
        <button class="next" onclick="moveSlide(1)">&#10095;</button>
    </div>
    <div class="container">
        <h1 class="title">BLOOD GROUPS</h1>
        <p class="subtitle">blood group of any human being will mainly fall in any one of the following groups..</p>
        <div class="container1">
            <div class="blood-groupdiv">
                <ul class="blood-groups">
                    <li>A positive or A negative</li>
                    <li>B positive or B negative</li>
                    <li>O positive or O negative</li>
                    <li>AB positive or AB negative</li>
                </ul>
                <p>A healthy diet helps ensure a successful blood donation, and also makes you feel better! Check out the following recommended foods to eat prior to your donation.</p>
            </div>
            <div>
                <img src="images/blood-donor (1).jpg" alt="Be a hero. Give blood">
            </div>
        </div>
        <div>
            <h2 class="universal-title">UNIVERSAL DONORS AND RECIPIENTS</h2>
            <p class="universal-description">The most common blood type is O, followed by type A. Type O individuals are often called "universal donors" since their blood can be transfused into persons with any blood type. Those with type AB blood are called "universal recipients" because they can receive blood of any type.</p>

            <button class="donate-button"><a href="Registration.php" class="a">Become a Donar</a></button>
        </div>
    </div>
    <div class="poster-container">
        <div class="poster-content">
            <h1>Share Life Like You Share Wi-Fi</h1>
            <p class="p">This poster encourages blood donation by drawing a parallel between readily shared Wi-Fi and the life-saving potential of blood. The graphic depicts a smartphone, symbolizing connectivity and ease of access, nestled within a blood bag. It emphasizes the importance of sharing life-giving blood, much like sharing Wi-Fi, for the benefit of others.</p>
            <p class="p">The poster promotes a blood donation drive organized by Wings Foundation, specifying the date and time for the event.</p>
        </div>
        <img src="images/bloodsave.jpeg" alt="Blood Donation Poster" class="poster-image">
    </div>
    <?php include("footer.php") ?>
</body>

</html>