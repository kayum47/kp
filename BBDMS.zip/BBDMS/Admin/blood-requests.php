<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin |Blood Info Table</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background-color: #f4f4f4;
        }

        .container {
            margin: 30px 20px 10px 280px;
            font-family: Arial, sans-serif;
            max-width: 1100px;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: left;
            color: #333;
            padding-bottom: 10px;
            border-bottom: 2px solid #ddd;
            margin-bottom: 20px;
            font-size: 1.5rem;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            font-size: 0.9rem;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
            color: #333;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        td {
            color: #555;
        }
    </style>
</head>

<body>
    <?php
    include('header.php');
    include('sidebar.php');
    ?>
    <div class="container">
        <h2>BLOOD REQUEST INFO</h2>

        <table>
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Name of Donor</th>
                    <th>Contact Number of Donor</th>
                    <th>Blood Group</th>
                    <th>Name of Requirer</th>
                    <th>Mobile Number of Requirer</th>
                    <th>Email of Requirer</th>
                    <th>Blood Require For</th>
                    <th>Message of Requirer</th>
                    <th>Apply Date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <?php
                    include('includes/dbconnection.php');
                    $sdata = isset($_POST['sdata']) ? $_POST['sdata'] : '';
                    $sql = "SELECT 
                                bloodrequirer.BloodDonarid,
                                bloodrequirer.name AS requirer_name,
                                bloodrequirer.email AS requirer_email,
                                bloodrequirer.number AS requirer_number,
                                bloodrequirer.bloodrequirefor,
                                bloodrequirer.message,
                                bloodrequirer.ApplyDate,
                                blooddonars.fname AS donor_name,
                                blooddonars.number AS donor_number,
                                blooddonars.blood_group
                            FROM 
                                bloodrequirer 
                            JOIN 
                                blooddonars 
                            ON 
                                blooddonars.id = bloodrequirer.BloodDonarid
                            WHERE 
                                blooddonars.fname LIKE '%$sdata%' 
                            OR 
                                blooddonars.number LIKE '%$sdata%'";
                    $query = mysqli_query($con, $sql);
                    if ($query === false) {
                        echo "<tr><td colspan='10' style='color:red;'>Error: " . mysqli_error($con) . "</td></tr>";
                    } else {
                        $count = mysqli_num_rows($query);
                        $cnt = 1;

                        if ($count > 0) {
                            foreach ($query as $data) {
                    ?>
                                <td><?php echo ($cnt); ?></td>
                                <td><?php echo $data['donor_name']; ?></td>
                                <td><?php echo $data['donor_number']; ?></td>
                                <td><?php echo $data['blood_group']; ?></td>
                                <td><?php echo $data['requirer_name']; ?></td>
                                <td><?php echo $data['requirer_number']; ?></td>
                                <td><?php echo $data['requirer_email']; ?></td>
                                <td><?php echo $data['bloodrequirefor']; ?></td>
                                <td><?php echo $data['message']; ?></td>
                                <td><?php echo $data['ApplyDate']; ?></td>
                </tr>

            <?php
                                $cnt++;
                            }
                        } else {
            ?>
            <tr>
                <th colspan="10" style="color:red;"> No Record found</th>
            </tr>
    <?php
                        }
                    }
    ?>

            </tbody>
        </table>
    </div>

</body>

</html>