<?php include('includes/dbconnection.php');
$sql = "SELECT * FROM `blooddonars`";
$result = mysqli_query($con, $sql);

if (isset($_POST['delete'])) {
    $id = intval($_POST['id']);
    $delete = "DELETE FROM `blooddonars` WHERE `id`=$id";
    $result = mysqli_query($con, $delete);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Manage Contact Us Queries</title>
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <style>
        /* Custom styles for the table */
        .container {
            margin: 30px 20px 10px 280px;
            /*width: 90%;*/
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: #fff;
        }

        table.dataTable {
            border-collapse: collapse;
            border: 1px solid #ddd;
            width: 100%;
            background-color: white;
        }

        table.dataTable thead th {
            border-bottom: 2px solid #ddd;
        }

        table.dataTable th,
        table.dataTable td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table.dataTable tbody tr:hover {
            background-color: #f1f1f1;
        }

        .dataTables_wrapper {
            margin: 20px;
        }

        .delete-btn {
            background-color: #ff4c4c;
            /* Red background color */
            color: white;
            /* White text color */
            border: none;
            /* No border */
            padding: 8px 16px;
            /* Padding for size */
            font-size: 14px;
            /* Font size */
            border-radius: 4px;
            /* Rounded corners */
            cursor: pointer;
            /* Pointer cursor on hover */
            transition: background-color 0.3s ease;
            /* Smooth transition for hover effect */
        }

        .delete-btn:hover {
            background-color: #ff3333;
            /* Darker red on hover */
        }
    </style>
    <script>
        function confirmDelete() {
            return confirm('Are you sure you want to delete this record?');
        }
    </script>
</head>

<body>
    <?php
    include('header.php');
    include('sidebar.php');
    ?>
    <div class="container">
        <h2>Manage Contact Us Queries</h2>
        <table id="queryTable" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Full Name</th>
                    <th>Contact No</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Blood Group</th>
                    <th>Address</th>
                    <th>State</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($data = mysqli_fetch_assoc($result)) {
                    $id = $data['id'];
                ?>
                    <tr>
                        <td><?php echo $data['id']; ?></td>
                        <td><?php echo $data['fname']; ?></td>
                        <td><?php echo $data['number']; ?></td>
                        <td><?php echo $data['email']; ?></td>
                        <td><?php echo $data['age']; ?></td>
                        <td><?php echo $data['gender']; ?></td>
                        <td><?php echo $data['blood_group']; ?></td>
                        <td><?php echo $data['address']; ?></td>
                        <td><?php echo $data['state']; ?></td>
                        <td>
                            <form method="POST" style="display:inline;" onsubmit="return confirmDelete();">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                                <button type="submit" class="delete-btn" name="delete">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>

    <script>
        $(document).ready(function() {
            $('#queryTable').DataTable({
                "paging": true, // Enable pagination
                "searching": true, // Enable searching
                "info": true, // Show table information
                "columnDefs": [{
                        "orderable": false,
                        "targets": 6
                    } // Disable ordering for the 'Action' column
                ]
            });
        });
    </script>
</body>

</html>