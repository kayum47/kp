
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">

<style>
    /* General Sidebar Styling */
    .ts-sidebar {
        margin-top: 69px;
        width: 260px;
        background-color: black;
        position:fixed;
        height: 100%;
        top: 0;
        left: 0;
        overflow-y: auto;
        padding-top: 30px;
        transition: all 0.3s ease;
        box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    }

    .ts-sidebar-menu {
        list-style-type: none;
        padding: 0;
        margin: 0;
    }

    .ts-sidebar-menu li {
        position: relative;
        padding: 5px;
    }

    .ts-sidebar-menu li a {
        color: #ecf0f1;
        text-decoration: none;
        display: block;
        font-size: 16px;
        padding: 12px 20px;
        border-left: 4px solid transparent;
        transition: all 0.3s ease;
    }

    .ts-sidebar-menu li a:hover,
    .ts-sidebar-menu li a.active {
        background-color: red;
        border-left-color: #e74c3c;
        color: #fff;
    }

    .ts-sidebar-menu .ts-label {
        color: #bdc3c7;
        font-size: 14px;
        padding: 10px 20px;
        text-transform: uppercase;
        font-weight: bold;
    }

    .ts-sidebar-menu li ul {
        list-style-type: none;
        padding-left: 0;
        display: none;
        background-color: #34495e;
    }

    .ts-sidebar-menu li ul li a {
        padding: 10px 40px;
        font-size: 14px;
        background-color: black;
        border-left: 4px solid transparent;
    }

    .ts-sidebar-menu li:hover ul {
        display: block;
    }

    /* Icon Styling */
    .ts-sidebar-menu li a i {
        margin-right: 15px;
        font-size: 18px;
        vertical-align: middle;
    }

    /* Hover Effect for Submenu */
    .ts-sidebar-menu li ul li a:hover,
    .ts-sidebar-menu li ul li a.active {
        background-color: red;
        border-left-color: #e74c3c;
    }

    /* Responsive Styling */
    @media (max-width: 768px) {
        .ts-sidebar {
            width: 220px;
        }

        .ts-sidebar-menu li a {
            font-size: 15px;
            padding: 10px 15px;
        }

        .ts-sidebar-menu li ul li a {
            padding: 8px 35px;
            font-size: 13px;
        }
    }
</style>
<nav class="ts-sidebar">
    <ul class="ts-sidebar-menu">

        <li class="ts-label">Main</li>
        <li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>

        <li><a href="#"><i class="fa-regular fa-copy"></i> Blood Group</a>
            <ul>
                <li><a href="add-bloodgroup.php">Add Blood Group</a></li>
                <li><a href="manage-bloodgroup.php">Manage Blood Group</a></li>
            </ul>
        </li>
        <li><a href="donor-list.php"><i class="fa fa-users"></i> Donor List</a></li>
        <li><a href="manage-contactusquery.php"><i class="fa fa-desktop"></i> Manage Contactus Query</a></li>
        <li><a href="blood-requests.php"><i class="fa fa-users"></i> Blood Requests</a></li>
        <li><a href="update-contactusinfo.php"><i class="fa-regular fa-copy"></i> Update Contact Info</a></li>
    </ul>
</nav>