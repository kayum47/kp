<?php
session_start();
 include('includes/dbconnection.php');
$sql = "SELECT * FROM `blooddonars`";
$result = mysqli_query($con, $sql);
?>

<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Blood Donor List</title>
    <style>
        body {
            background-color: #f0f0f0;
        }
        .title {
            text-align: center;
            font-size: 2em;
            border-bottom: 2px solid black;
            margin: 80px auto 0;
        }

        .container {
            margin-top: 40px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            justify-content: space-between;
            padding: 20px;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            padding: 20px;
            margin-right: 10px;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
        }

        .profile {
            text-align: center;
            margin-bottom: 15px;
        }

        .avatar {
            width: 380px;
            height: 300px;
            border-radius: 5%;
            margin: 0 auto 30px;
        }

        .name {
            font-size: 30px;
            font-weight: bold;
        }

        .details table {
            width: 100%;
            border-spacing: 1;
            font-size: 16px;
        }

        .details td {
            padding: 8px 0;

        }
    </style>
</head>
<body>
<?php include("header.php")?>
    <div>
    <h1 class="title">Blood Donor List</h1>
        <div class="container">
            <?php
            while ($data = mysqli_fetch_assoc($result)) {
                $id = $data['id'];
            ?>
                <div class="card">

                    <div class="profile">
                        <img src="images/blood-donor.jpg" alt="Blood Donot" style="border:1px #000 solid" class="avatar" />
                        <div class="name"><?php echo $data['fname']; ?></div>
                    </div>
                    <div class="details">
                        <table>
                            <tr>
                                <td>Gender</td>
                                <td><?php echo $data['gender']; ?></td>
                            </tr>
                            <tr>
                                <td>Blood Group</td>
                                <td><?php echo $data['blood_group']; ?></td>
                            </tr>
                            <tr>
                                <td>Date-of-birth</td>
                                <td><?php echo $data['date-of-birth']; ?></td>
                            </tr>
                            <tr>
                                <td>Email ID</td>
                                <td><?php echo $data['email']; ?></td>
                            </tr>
                            <tr>
                                <td>Age</td>
                                <td><?php echo $data['age']; ?></td>
                            </tr>
                            <tr>
                                <td>State</td>
                                <td><?php echo $data['state']; ?></td>
                            </tr>
                        </table>
                    </div>
                    <br>
                </div>
            <?php
            }
            ?>
        </div>
    </div>
    <?php include("footer.php") ?>
</body>

</html>