<?php
session_start();
include('includes/dbconnection.php');
$sql = "SELECT * FROM `blooddonars`";
$result = mysqli_query($con, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBDMS | Blood Donor List</title>
    <style>
        .container {
            max-width: 1250px;
            margin: 0 auto;
            padding: 20px;
            background-color: whitesmoke;
            border-radius: 5px;
        }

        .title {
            text-align: center;
            font-size: 2.5em;
            font-weight: bold;
            margin-top: 70px;
            padding-bottom: 10px;
            color: #2c3e50;
            border-bottom: 2px solid #2c3e50;
        }

        .grid-container {
            margin-top: 40px;
            display: grid;
            grid-template-columns: repeat(3, minmax(300px, 1fr));
            gap: 10px;
            padding: 20px 0;
        }

        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
        }

        .profile {
            text-align: center;
            margin-bottom: 15px;
        }

        .avatar {
            width: 100%;
            max-width: 250px;
            height: auto;
            border-radius: 5%;
            margin: 0 auto 30px;
        }

        .name {
            font-size: 24px;
            font-weight: bold;
            color: #2980b9;
        }

        .details table {
            width: 100%;
            border-spacing: 1;
            font-size: 16px;
        }

        .details td {
            padding: 8px 0;
        }

        .reveal-button {
            display: inline-block;
            margin-top: 15px;
            padding: 15px 25px;
            background-color: #2980b9;
            color: white;
            border: none;
            border-radius: 7px;
            cursor: pointer;
            font-size: 15px;
        }

        .reveal-button:hover {
            background-color: #1f6397;
        }

        /* Media Queries for smaller screens */
        @media (max-width: 600px) {
            .title {
                font-size: 2em;
            }

            .grid-container {
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            }

            .name {
                font-size: 20px;
            }
        }
    </style>
</head>

<body>
    <?php include("header.php") ?>

    <div class="container">
        <h1 class="title">Blood Donor List</h1>
        <div class="grid-container">
            <?php
            while ($data = mysqli_fetch_assoc($result)) {
                $id = $data['id'];
            ?>
                <div class="card">
                    <div class="profile">
                        <img src="images/blood-donor.jpg" alt="Blood Donor" class="avatar" />
                        <div class="name"><?php echo $data['fname']; ?></div>
                    </div>
                    <div class="details">
                        <table>
                            <tr>
                                <td>Gender</td>
                                <td><?php echo $data['gender']; ?></td>
                            </tr>
                            <tr>
                                <td>Blood Group</td>
                                <td><?php echo $data['blood_group']; ?></td>
                            </tr>
                            <tr>
                                <td>Date-of-birth</td>
                                <td><?php echo $data['date-of-birth']; ?></td>
                            </tr>
                            <tr>
                                <td>Email ID</td>
                                <td><?php echo $data['email']; ?></td>
                            </tr>
                            <tr>
                                <td>Age</td>
                                <td><?php echo $data['age']; ?></td>
                            </tr>
                            <tr>
                                <td>City</td>
                                <td><?php echo $data['state']; ?></td>
                            </tr>
                            <tr>
                                <td>Contact Number</td>
                                <td><?php echo $data['number']; ?></td>
                            </tr>
                        </table>
                    </div>
                    <a class="reveal-button" style="color:#fff; text-decoration: none;"  href="contact-blood.php?cid=<?php echo $data['id'];?>">Request</a>
                </div>
            <?php
            }
            ?>
        </div>
    </div>

    <?php include("footer.php") ?>
</body>

</html>
